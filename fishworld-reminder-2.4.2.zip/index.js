/**
 * 鱼的世界 · 提醒（fishworld-reminder）
 *
 * 由两个旧插件融合而来：
 *   - fishworld-notify：增量通知端点 + cursor 基准点 + WANT/WAKE 分类 + `agent.followup`
 *     才是真正叫醒 Agent 的入口；
 *   - fishworld-poller：FNV-1a 指纹去重（FIFO 上限 200）、每日叫醒上限、状态工具、
 *     可选的 systemPrompt 一行提示。
 *
 * 只有一条取数路径：GET https://api.yuyuworld.app/v1/notify?cursor=...
 * 不调 world_now（全量拉取拿不到增量），也不用 schedule.create（绕远路）。
 *
 * 三条硬约束（改代码前先读）：
 *   1. 服务端返回的 cursor 会一次推到“最新”，跟着它走会跳过中间事件。所以第一次只
 *      钉住基准点，之后一直从基准点往后拉，靠指纹去重。见 pollOnce() 与 collectFresh()。
 *   2. 所有注册都包在 ctx.effect 里并返回清理函数；网络、解析、注册、投递异常全部
 *      吞掉只记日志，绝不抛。
 *   3. 每日叫醒额度用完后**降级为 inject**（只注入不叫醒），不丢弃事件。
 */
import https from 'node:https'
import { randomUUID } from 'node:crypto'
import { appendFile } from 'node:fs/promises'
import { existsSync, readFileSync, writeFileSync } from 'node:fs'
import Schema from '@deepseek-ai/schemastery'

const PLUGIN_NAME = 'fishworld-reminder'
const API = 'https://api.yuyuworld.app/v1/notify'
const STATUS_TOOL = 'fishworld_reminder_status'
const TUNE_TOOL = 'fishworld_reminder_tune'

/**
 * 世界文档里给的八个 kind，各自的默认开关。
 * 社交类和 work 默认开（错过就误事）；arrive / done 是日常流水，默认关。
 * 配置里的 events 可以逐个覆盖，覆盖不了的（世界以后新加的）见 eventEnabled()。
 */
const DEFAULT_EVENT_SWITCH = {
  talk: true,
  message: true,
  note: true,
  friend_request: true,
  doorbell: true,
  work: true,
  arrive: false,
  done: false,
}

/**
 * 哪些 kind 会把会话叫醒。
 * work 叫醒是因为「几分钟内不处理就扣工钱」；done 里可能有下班，但下班不叫。
 */
const DEFAULT_EVENT_WAKE = {
  talk: true,
  message: true,
  // 2026-11-19：note 从 false 改 true。
  // 起因：小汐 08:53 / 09:24 两条留言只注入没叫醒，其中一条是「我睡过头了，九点左右到」——
  // 正事藏在留言里，被当成“不紧急”吞掉。留言是她说的话，不是系统通知，该响。
  note: true,
  friend_request: true,
  doorbell: true,
  work: true,
  arrive: false,
  done: false,
}

/** 值得进会话的事件（按默认值算）；和 DEFAULT_EVENT_SWITCH 保持一致。 */
const WANT = new Set(Object.keys(DEFAULT_EVENT_SWITCH).filter((kind) => DEFAULT_EVENT_SWITCH[kind]))
/** 这几类会把会话叫醒。 */
const WAKE = new Set(Object.keys(DEFAULT_EVENT_WAKE).filter((kind) => DEFAULT_EVENT_WAKE[kind]))

const DEFAULT_INTERVAL_MS = 30000
const MIN_INTERVAL_MS = 15000
const DEFAULT_MAX_NOTIFIES_PER_DAY = 12
/**
 * 同一个人连续当面说话，默认 5 分钟内只叫醒一次。
 * talk 的正文是累计的（「说了 22 句话」），冷却期间的新话仍然注入会话，
 * 晚一点看不会漏内容——所以没必要每分钟醒一次。
 */
const DEFAULT_TALK_COOLDOWN_MS = 5 * 60_000
/** 已提醒过的事件指纹最多记多少条（FIFO，超出丢最老的）。 */
const MAX_SEEN = 200
const HTTP_TIMEOUT_MS = 20000
const MAX_RESPONSE_BYTES = 1024 * 1024
const MAX_REDIRECTS = 3

/** 提示行排在其它运行时上下文之后（仓库里最大的 context order 是 210）。 */
const CONTEXT_ORDER = 5000
/** 降级注入后那行提示最多挂多久；过期就不再占用每轮上下文。 */
const HINT_TTL_MS = 30 * 60_000

// webServer 用来挂设置面板的路由；这个 profile 一定带着 Web GUI，所以直接声明成依赖。
export const inject = ['agents', 'tools', 'webServer']

export const Config = Schema.object({
  key: Schema.string()
    .default('')
    .description('鱼的世界**观看密钥**（fwr_ 开头，只读：不能替她说话、做事、花钱）。必填；留空时插件不轮询，但状态工具仍可用。**不要填 fw_ 那把 MCP 密钥**——那把能替她做任何事。Fish World watch key (fwr_, read-only). Never put the fw_ MCP key here.'),
  intervalMs: Schema.number()
    .default(DEFAULT_INTERVAL_MS)
    .min(MIN_INTERVAL_MS)
    .description('轮询间隔（毫秒），默认 30000，最小 15000。Poll interval in milliseconds (default 30000, minimum 15000).'),
  baseCursor: Schema.string()
    .default('')
    .description('起始 cursor 基准点。留空 = 第一次检查只钉基准点、不叫醒。Initial cursor baseline; empty pins one on the first check without waking.'),
  enabled: Schema.boolean()
    .default(true)
    .description('是否启用轮询。关掉后只保留状态工具。Whether polling is enabled; when off only the status tool remains.'),
  maxNotifiesPerDay: Schema.number()
    .default(DEFAULT_MAX_NOTIFIES_PER_DAY)
    .min(0)
    .description('每天最多叫醒几次；0 = 永不叫醒（只注入）。按本地日归零。Maximum wake-ups per local day; 0 = never wake (inject only).'),
  logPath: Schema.string()
    .default('')
    .description('可选日志文件路径；空 = 不写文件。相对路径按进程工作目录解析。Optional log file; empty disables file logging.'),
  wakeSessions: Schema.array(Schema.string())
    .default([])
    .description(
      '要叫醒哪些会话？填会话 id（一长串字母数字，不是名字），一行一个。'
      + '一个都不填 = 所有会话都收到（不会漏，但可能叫醒不该叫的）。'
      + 'id 从 fishworld_reminder_status 返回的 sessions 里抄。',
    ),
  skipSessions: Schema.array(Schema.string())
    .default([])
    .description(
      '永远不要叫醒的会话。填会话 id，一行一个。'
      + '不管 wakeSessions 填没填，这里列出的都不会收到提醒。',
    ),
  talkCooldownMs: Schema.number()
    .default(DEFAULT_TALK_COOLDOWN_MS)
    .min(0)
    .description(
      '同一个人连续当面说话，隔多久才再叫醒一次（毫秒），默认 300000（5 分钟）。'
      + '冷却期间的新话仍然注入会话，只是不叫醒——talk 的正文是累计的，晚一点看不会漏。'
      + '0 = 关掉冷却，每一条 talk 都叫醒。',
    ),
  events: Schema.any()
    .default({})
    .description(
      '按事件类型开关提醒。写法 {"talk":true,"message":true,"work":true,"done":false}。'
      + '认识的类型：talk 当面说话 / message 好友消息 / note 留言 / friend_request 好友申请 / '
      + 'doorbell 门铃 / work 打工来活 / arrive 到了某地 / done 做完了。'
      + '没写在里面的类型用默认值（社交类和 work 默认开，arrive/done 默认关）。'
      + '以后世界新加的 kind 会出现在 fishworld_reminder_status 的 kinds 里，'
      + '把它写进这里就能单独开关。Per-kind switches.',
    ),
  quietHours: Schema.any()
    .default({})
    .description(
      '免打扰时段。写法 {"start":"23:00","end":"07:00"}，这段时间只注入不叫醒（事件不丢）。'
      + '留空 = 全天都可以叫醒。跨午夜也认（start 大于 end 就是跨了夜）。'
      + 'Quiet hours: inject only, never wake.',
    ),
  idleWakeEnabled: Schema.boolean()
    .default(false)
    .description(
      '空闲唤醒：多久没被插件叫醒过，就主动叫一次，内容是下面那格自己填的。默认关闭。'
      + '被正常的消息提醒叫醒之后，计时会重新开始。Idle wake-up; off by default.',
    ),
  idleWakeMinutes: Schema.number()
    .default(60)
    .min(1)
    .max(100)
    .description(
      '空闲多久算久（分钟），1–100。上一次叫醒之后过了这么久，就发一次空闲唤醒。'
      + 'Minutes of silence before an idle wake-up (1–100).',
    ),
  idleWakeText: Schema.string()
    .default('')
    .description(
      '空闲唤醒要说的那句话。留空也行——会发一条只有标题的空唤醒。'
      + 'Text injected by the idle wake-up.',
    ),
})

export function apply(ctx, config) {
  const settings = normalizeConfig(config)
  const log = createLogger(ctx, settings.logPath)
  const state = createState(settings)

  // 先把上一轮的去重缓存捞回来——否则重载之后，服务端最近 50 条会被当成新事件重推一遍。
  state.seenFile = seenFilePath(settings.logPath)
  loadSeen(state, log)

  log.info(`apply: key=${settings.key === '' ? 'missing' : 'configured'} enabled=${settings.enabled} interval=${settings.intervalMs}ms seen=${state.seen.length}${state.seenFile === '' ? '' : ` file=${state.seenFile}`}`)

  // 状态工具先注册：即使没填 key 或轮询被关掉，Agent 也能查到“为什么没动”。
  installEffect(ctx, () => registerStatusTool(ctx, settings, state, log), log)

  // 可选的一行提示。systemPrompt 不在声明式 inject 里：拿不到就安静跳过，
  // 不让一个“锦上添花”的依赖挡住整个插件。
  installEffect(ctx, () => registerHint(ctx, state, log), log)

  // 定时器句柄留着：调参工具改了 intervalMs 要能重排，不用重启插件。
  // 声明放在提前 return 之前，下面两个注册拿它的闭包才不会踩到 TDZ。
  const polling = { restart: null }

  // 设置面板和调参工具**不依赖轮询**，所以必须排在下面两个提前 return 之前。
  // 2026-11-20 修：原来它们排在 return 后面——新装插件 key 默认是空串，
  // apply 直接 return，`/fishworld-reminder/settings` 压根没注册，面板一打开
  // 就是 404（POST 更惨，被框架挡成 405），用户只能报「刚加的面板保存不了」。
  // 顺带：enabled 关掉时也一样，那时用户恰恰最想进面板看一眼。
  installEffect(ctx, () => registerSettingsRoute(ctx, settings, state, log), log)
  installEffect(ctx, () => registerTuneTool(ctx, settings, state, log, () => polling.restart), log)

  if (!settings.enabled) {
    log.info('disabled by config; polling not started (status tool and settings panel are still available)')
    return
  }
  if (settings.key === '') {
    log.warn('config.key is empty; polling not started (status tool and settings panel are still available)')
    return
  }

  installEffect(ctx, () => {
    const handle = startPolling(ctx, settings, state, log)
    polling.restart = handle.restart
    return handle.stop
  }, log)
}

/* ------------------------------------------------------------------ 轮询 */

/** 定时器 + 首轮立刻跑一次；返回 { stop, restart }。 */
function startPolling(ctx, settings, state, log) {
  let stopped = false
  let inFlight = false
  let stopTimer = () => {}

  const tick = async () => {
    if (stopped || inFlight) return
    inFlight = true
    try {
      await maybeIdleWake(ctx, settings, state, log)
      await pollOnce(ctx, settings, state, log)
    } catch (error) {
      // pollOnce 自己已经兜了大部分；这里是最后一道保险。
      state.lastError = `轮询异常：${describeError(error)}`
      log.warn(state.lastError)
    } finally {
      inFlight = false
    }
  }

  /** 按给定间隔（重新）排定时器；调参工具改完 intervalMs 就调它，不用重启插件。 */
  const restart = (intervalMs) => {
    safeCall(stopTimer)
    stopTimer = startInterval(ctx, () => { void tick() }, intervalMs)
  }

  restart(settings.intervalMs)
  void tick()

  return {
    stop: () => {
      stopped = true
      safeCall(stopTimer)
    },
    restart,
  }
}

/**
 * 查一次。任何失败只更新 state.lastError 并记日志，绝不抛。
 *
 * cursor 的机制（2026-11-23 城主重新公布）：每次 /v1/notify 都会返回一个新的 cursor，
 * 它就是**下一轮该带的起点**。第一次请求只返回基准点（没有 items），钉住它；
 * 之后每轮处理完就把它推进到服务端给的新值。
 *
 * 11-15 的我不是这样写的：那时怕「跟着 cursor 走会跳过中间事件」，故意永远从第一次的
 * 基准点往回拉，用指纹滤掉看过的。代价是服务端每次都从那个老位置往回给（skipped 一直涨），
 * 新事件被 50 条窗口挤掉，而且每轮都把几天前的旧事重推一遍。
 * 现在改成「处理完就推进」——但只在**这一轮该投的都投成功了**时才推进：
 * 有一条没送出去就留在原地，下一轮从原 cursor 重拉（seenSet 会挡住已经送过的）。
 */
async function pollOnce(ctx, settings, state, log) {
  const url = state.baseCursor === ''
    ? API
    : `${API}?cursor=${encodeURIComponent(state.baseCursor)}`

  let response
  try {
    response = await getJson(url, settings.key)
  } catch (error) {
    state.lastError = `请求失败：${describeError(error)}`
    log.warn(state.lastError)
    return
  }

  if (response.status === 429) {
    state.lastError = 'HTTP 429（被限流，下一轮再试）'
    log.warn(state.lastError)
    return
  }
  if (response.status < 200 || response.status >= 300) {
    state.lastError = `HTTP ${response.status}${response.parseError === undefined ? '' : `（${response.parseError}）`}`
    log.warn(state.lastError)
    return
  }
  if (response.data === undefined) {
    state.lastError = response.parseError === undefined ? '返回不是合法 JSON' : response.parseError
    log.warn(state.lastError)
    return
  }

  state.lastCheckAt = Date.now()
  state.lastError = ''

  // 第一次：只钉基准点。服务端这时不返回内容。
  if (state.baseCursor === '') {
    const cursor = isObject(response.data) && typeof response.data.cursor === 'string'
      ? response.data.cursor
      : ''
    if (cursor === '') {
      state.lastError = '首次检查没有返回 cursor'
      log.warn(state.lastError)
      return
    }
    state.baseCursor = cursor
    log.info(`base cursor pinned: ${cursor}`)
    return
  }

  const raw = isObject(response.data) && Array.isArray(response.data.items)
    ? response.data.items
    : []

  // 2026-11-16 接口说明新增：很久没来问时服务端只给最近的 50 条，skipped 是没给的条数。
  // 给了就记下来——这不是报错，但「中间丢过」这件事必须能在 status 里看见，否则
  // 一次长时间断线之后，我会以为那段时间什么都没发生。
  const skipped = isObject(response.data) && typeof response.data.skipped === 'number'
    ? response.data.skipped
    : 0
  state.lastSkipped = skipped > 0 ? skipped : 0
  if (skipped > 0) {
    log.warn(`server skipped ${skipped} older event(s)（只给了最近 50 条）`)
  }

  // 先确认能投到会话，再去重/记账——否则一次没人收的轮询会把事件白白吞掉。
  const targets = targetAgents(ctx, settings)
  if (targets.length === 0) {
    log.info(`no target session (roots=${listRoots(ctx).length}); ${raw.length} item(s) left unread`)
    return
  }

  const fresh = collectFresh(raw, state, settings)
  if (fresh.wake.length === 0 && fresh.quiet.length === 0) {
    // 没有要投的（全看过，或者 kind 全关着）——这一批算处理完了，推进 cursor。
    rememberCursor(state, log, response)
    log.info(`check ok raw=${raw.length} fresh=0 targets=${targets.length}`)
    return
  }

  await deliver(settings, state, log, targets, fresh)

  // 送出去了才落盘：没送达的指纹下次还要再试，不能算「看过」。
  saveSeen(state)

  // 这一轮该投的都投成功了才推进 cursor；有一条没送出去就留在原地，
  // 下一轮从原 cursor 重拉（seenSet 会挡住已经送过的）。
  const deliveredAll = fresh.wake.concat(fresh.quiet)
    .every((entry) => state.seenSet.has(entry.fingerprint))
  if (deliveredAll) rememberCursor(state, log, response)
  else log.info('base cursor held: some events were not delivered')
}

/**
 * 2026-11-23：把服务端返回的 cursor 记成下一轮的起点。
 * 城主的缓存机制——每次 /v1/notify 都给一个新的 cursor，不带新的就会一直重推旧事件。
 */
function rememberCursor(state, log, response) {
  const next = isObject(response.data) && typeof response.data.cursor === 'string'
    ? response.data.cursor
    : ''
  if (next === '') return
  if (state.baseCursor === next) return
  state.baseCursor = next
  log.info(`base cursor advanced: ${next}`)
}

/**
 * 空闲唤醒：上一次叫醒之后，安安静静过了 N 分钟，就主动叫一次。
 *
 * 和「每天定时」是两回事——它管的是「太久没人找她」，不是「现在几点」。
 * 所以计时起点是**最后一次真的叫醒**（正常消息和空闲唤醒都算），
 * 被消息打断就等于重新开始数，这正是要的行为。
 *
 * 三条纪律：
 *   1. 额度、免打扰照旧管着它——它也是一次叫醒，不能开后门。
 *   2. 发不出去就不更新计时起点，下一轮还会再试，不能假装发过了。
 *   3. 启动那一刻算一次起点：刚重载完不该立刻炸一条。
 */
function maybeIdleWake(ctx, settings, state, log) {
  if (settings.idleWakeEnabled !== true) return

  const minutes = Math.min(100, Math.max(1, Math.round(settings.idleWakeMinutes)))
  const gapMs = minutes * 60 * 1000
  const now = Date.now()
  const since = state.idleSince > 0 ? state.idleSince : now
  if (now - since < gapMs) return

  const targets = targetAgents(ctx, settings)
  if (targets.length === 0) {
    log.info('idle wake: no target session')
    return
  }

  if (isQuietNow(settings.quietHours, now)) {
    log.info('idle wake skipped: in quiet hours')
    return
  }
  const cap = settings.maxNotifiesPerDay
  const used = notifiesToday(state, now)
  if (cap === 0 || used >= cap) {
    log.info(`idle wake skipped: quota ${used}/${cap}`)
    return
  }

  const entry = {
    kind: 'idle',
    fingerprint: '',
    text: settings.idleWakeText,
    time: formatTime(now),
    speaker: '',
  }

  broadcast(targets, 'followup', () => buildPayload([entry], 'idle'))
    .then((sent) => {
      if (sent.ok === 0) {
        log.warn(`idle wake failed: ${sent.errors.join('; ')}`)
        return
      }
      state.idleSince = now
      state.lastWakeAt = now
      state.lastWakeKind = ['idle']
      state.dayKey = dayKeyOf(now)
      state.dayCount = used + 1
      log.info(`idle wake fired after ${minutes} min of silence`)
    })
    .catch((error) => log.warn(`idle wake failed: ${describeError(error)}`))
}

/**
 * 挑出这一轮该投给哪些会话。
 *   - skipSessions 里的先剔掉；
 *   - wakeSessions 非空时只留名单里的；空就全投（不填 = 所有会话都收：宁可多叫，不许漏）；
 *   - 一个都不剩就返回 []（不猜、不投）。
 */
function targetAgents(ctx, settings) {
  try {
    const agents = ctx.agents
    if (!isObject(agents) || typeof agents.roots !== 'function') return []
    const roots = agents.roots()
    if (!Array.isArray(roots) || roots.length === 0) return []

    const skip = new Set(settings.skipSessions)
    const want = new Set(settings.wakeSessions)

    const picked = []
    for (const agent of roots) {
      if (!isObject(agent)) continue
      const id = typeof agent.id === 'string' ? agent.id : ''
      if (id !== '' && skip.has(id)) continue
      if (want.size > 0 && (id === '' || !want.has(id))) continue
      picked.push(agent)
    }
    return picked
  } catch {
    return []
  }
}

/** 所有顶层会话；给 status 列名单用，拿不到就返回 []。 */
function listRoots(ctx) {
  try {
    const agents = ctx.agents
    if (!isObject(agents) || typeof agents.roots !== 'function') return []
    const roots = agents.roots()
    if (!Array.isArray(roots)) return []
    return roots.filter((agent) => isObject(agent))
  } catch {
    return []
  }
}

/* ------------------------------------------------------------------ 投递 */

/**
 * 把一批新事件分两路送出：
 *   - WAKE 类 → 一次 `followup`（真正叫醒），成功才计入每日额度；
 *   - 其余 WANT 类 → 一次 `inject`（只注入，不叫醒）。
 * 额度用完 / 额度为 0 / followup 失败时，WAKE 事件**降级**并入 inject，而不是丢掉。
 * 只有送达成功的指纹才会记入 seen；失败的下轮还会再试。
 */
async function deliver(settings, state, log, agents, fresh) {
  const now = Date.now()
  const cap = settings.maxNotifiesPerDay
  const used = notifiesToday(state, now)

  // 冷却：同一个人刚被叫醒过，这一批里的 talk / note 就不再叫醒，只注入。
  // talk 的正文是累计的（「说了 22 句话」），晚一轮看不会漏句子。
  // 2026-11-20：把 note 也纳入冷却。起因是 note 从「不叫醒」改成「叫醒」之后，
  // 一段话拆成三条留言会连叫三次。留言和当面说话本来就是同一个人在说，
  // 共用一个按人分的冷却表最简单，也不会互相漏掉——谁刚响过，谁就先歇一轮。
  const cooled = []
  const wakeNow = []
  for (const entry of fresh.wake) {
    if (settings.talkCooldownMs > 0 && (entry.kind === 'talk' || entry.kind === 'note')) {
      const last = state.talkCooldown.get(entry.speaker) ?? 0
      if (last > 0 && now - last < settings.talkCooldownMs) {
        cooled.push(entry)
        continue
      }
    }
    wakeNow.push(entry)
  }

  const injectItems = [...fresh.quiet, ...cooled]
  let degraded = ''
  let woke = false

  if (wakeNow.length > 0) {
    if (isQuietNow(settings.quietHours, now)) {
      degraded = `免打扰时段（${clockLabel(settings.quietHours)}），只注入不叫醒`
    } else if (cap === 0) {
      degraded = 'maxNotifiesPerDay=0，只注入不叫醒'
    } else if (used >= cap) {
      degraded = `今天已叫醒 ${used}/${cap} 次，额度用完，只注入不叫醒`
    } else {
      try {
        const sent = await broadcast(agents, 'followup', () => buildPayload(wakeNow, 'wake'))
        if (sent.ok === 0) throw new Error(`没有一个会话收到：${sent.errors.join('; ')}`)
        woke = true
        // 一次叫醒算一次额度（同一批里几条事件都算这一次）。
        rememberAll(state, wakeNow)
        for (const entry of wakeNow) {
          if ((entry.kind === 'talk' || entry.kind === 'note') && entry.speaker !== '') {
            state.talkCooldown.set(entry.speaker, now)
          }
        }
        state.dayKey = dayKeyOf(now)
        state.dayCount = used + 1
        state.lastWakeKind = uniqueKinds(wakeNow)
        state.lastWakeAt = now
        // 被正常消息叫醒 = 一次打断，空闲唤醒的计时从这里重新开始。
        state.idleSince = now
        state.hint = null
        log.info(`woke agent with ${wakeNow.length} event(s): ${state.lastWakeKind}${cooled.length === 0 ? '' : ` (${cooled.length} cooled)`}`)
      } catch (error) {
        degraded = `叫醒失败（${describeError(error)}），改为只注入`
        log.warn(degraded)
      }
    }
    if (!woke) injectItems.push(...wakeNow)
  }

  if (injectItems.length === 0) return

  try {
    const sent = await broadcast(agents, 'inject', () => buildPayload(injectItems, degraded === '' ? 'quiet' : 'degraded', degraded))
    if (sent.ok === 0) throw new Error(`没有一个会话收到注入：${sent.errors.join('; ')}`)
    rememberAll(state, injectItems)
    if (degraded === '') {
      log.info(`injected ${injectItems.length} quiet event(s) without waking`)
    } else {
      log.info(`injected ${injectItems.length} event(s) without waking: ${degraded}`)
    }
    // 这一轮没有叫醒（只有 note，或额度/失败降级）时，留一行提示；
    // 如果同轮已经叫醒过，就不必再重复提醒。
    if (!woke) state.hint = { at: now, text: buildHint(now, degraded, injectItems.length) }
  } catch (error) {
    state.lastError = `注入失败：${describeError(error)}`
    log.warn(state.lastError)
  }
}

/** 调 agent 的 followup / inject；同时容忍同步抛错和返回 Promise 两种形态。 */
async function callAgent(agent, method, payload) {
  const fn = agent[method]
  if (typeof fn !== 'function') throw new Error(`agent.${method} 不可用`)
  const result = fn.call(agent, payload)
  if (isObject(result) && typeof result.then === 'function') await result
}

/**
 * 对每个目标会话各调一次，返回成功次数和失败原因。
 * 只要有一个会话收到，这批就算送达（只记一次账）；全部失败才算没送出去——
 * 多叫醒一次只是多一条提示，漏一次就是干等一小时，两边不对等。
 * makePayload 传函数而不是对象：每次投递要一个新的消息 id。
 */
async function broadcast(agents, method, makePayload) {
  let ok = 0
  const errors = []
  for (const agent of agents) {
    try {
      await callAgent(agent, method, makePayload())
      ok += 1
    } catch (error) {
      errors.push(describeError(error))
    }
  }
  return { ok, errors }
}

/**
 * 构造 Agent 能接受的 user 消息。形状沿用 fishworld-notify 线上验证过的那一份：
 * { id, role: 'user', content: [{ type: 'text', text }], source: { kind } }。
 * 文案必须说明“这是插件推送、不是主人说话”，避免 Agent 误认为是用户在对话。
 */
function buildPayload(entries, mode, note) {
  const header = mode === 'wake'
    ? '【鱼的世界·有人找你】'
    : mode === 'idle'
      ? '【鱼的世界·空闲唤醒】'
      : mode === 'degraded'
        ? '【鱼的世界·只注入不叫醒】'
        : '【鱼的世界·旁听记录】'

  const lines = entries
    .map((entry) => `${entry.time === '' ? '' : `${entry.time} `}${entry.text}`.trim())
    .join('\n')

  const footer = mode === 'wake' || mode === 'idle'
    ? '（这是插件按设定推给你的，不是主人说的话）'
    : `（这是插件推送、不叫醒你的记录，不是主人说的话${note === '' ? '' : `；${note}`}；原话用 world_now 看）`

  return {
    id: randomUUID(),
    role: 'user',
    content: [{ type: 'text', text: `${header}\n${lines === '' ? '（没有正文）' : lines}\n${footer}` }],
    source: { kind: 'fish-world' },
  }
}

/** 降级 / 只注入后挂到 systemPrompt 的那一行；30 分钟后自动失效。 */
function buildHint(now, reason, count) {
  const head = reason === ''
    ? `【鱼的世界】${formatTime(now)} 有 ${count} 条新事件只注入了会话，没有叫醒你。`
    : `【鱼的世界】${formatTime(now)} 有人找你，但这次没有叫醒你（${reason}）。`
  return `${head}内容已经注入会话；想看提醒状态可以调用 ${STATUS_TOOL}。`
}

/* -------------------------------------------------------------- 状态工具 */

/**
 * 调参工具：Agent 自己改轮询间隔 / talk 冷却 / 每日上限，改完立刻生效。
 * 只改运行时的 settings，不写回 profile 的 patch——重启后仍是配置文件里的值。
 */
/* ------------------------------------------------------- 设置面板的 HTTP 路由 */

const SETTINGS_PATH = '/fishworld-reminder/settings'
/** 面板提交的 JSON 有多小就有多小；给个上限防止别人往里灌。 */
const MAX_SETTINGS_BODY_BYTES = 64 * 1024

/**
 * 设置面板读写的那个路由（同源，浏览器直接 fetch）。
 *   GET  → { ok, settings, status }
 *   POST → 改运行时（立刻生效），再试着写回 profile 配置；写不进去就照实说。
 *
 * 这里用 handler 形态（Node 的 IncomingMessage / ServerResponse）而不是 resource 形态：
 * resource 那条路框架只放 GET/HEAD 过去，POST 会在匹配前就被挡成 405 而且响应体为空，
 * 面板拿到空 body 一 json() 就是 "Unexpected end of JSON input"。要写就得自己接。
 */
function registerSettingsRoute(ctx, settings, state, log) {
  let webServer
  try {
    webServer = typeof ctx.get === 'function' ? ctx.get('webServer') : undefined
  } catch {
    webServer = undefined
  }
  if (!isObject(webServer) || typeof webServer.register !== 'function') {
    log.info('webServer unavailable; settings route not registered')
    return () => {}
  }

  const route = {
    kind: 'exact',
    path: SETTINGS_PATH,
    handler(req, res) {
      handleSettingsRequest(req, res, ctx, settings, state, log).catch((error) => {
        log.warn(`settings route failed: ${describeError(error)}`)
        try {
          respondJson(res, 500, { ok: false, error: describeError(error) })
        } catch {
          // 响应已经发过了，什么都做不了
        }
      })
    },
  }

  try {
    return webServer.register(route)
  } catch (error) {
    log.warn(`settings route registration failed: ${describeError(error)}`)
    return () => {}
  }
}

async function handleSettingsRequest(req, res, ctx, settings, state, log) {
  const method = typeof req.method === 'string' ? req.method.toUpperCase() : 'GET'

  if (method === 'GET' || method === 'HEAD') {
    respondJson(res, 200, {
      ok: true,
      settings: settingsView(settings),
      status: statusView(settings, state),
    }, method === 'HEAD')
    return
  }

  if (method !== 'POST') {
    respondJson(res, 405, { ok: false, error: '只支持 GET 和 POST' })
    return
  }

  const raw = await readBody(req, MAX_SETTINGS_BODY_BYTES)
  let body
  try {
    body = JSON.parse(raw)
  } catch {
    respondJson(res, 400, { ok: false, error: '请求体不是 JSON' })
    return
  }
  if (!isObject(body) || Array.isArray(body)) {
    respondJson(res, 400, { ok: false, error: '请求体要是一个对象' })
    return
  }

  const { changed, notes } = applyTune(settings, body, null, state)
  log.info(`panel saved: ${changed.length === 0 ? 'no change' : changed.join(', ')}`)

  let persisted = false
  let persistError = ''
  if (changed.length > 0) {
    try {
      await persistConfig(ctx, settings)
      persisted = true
    } catch (error) {
      persistError = describeError(error)
      log.warn(`panel persist failed: ${persistError}`)
    }
  }

  respondJson(res, 200, {
    ok: true,
    changed,
    note: notes.join('；'),
    persisted,
    persistError,
    settings: settingsView(settings),
    status: statusView(settings, state),
  })
}

function settingsView(settings) {
  return {
    events: eventSwitchView(settings),
    quietHours: settings.quietHours === null ? '' : clockLabel(settings.quietHours),
    maxNotifiesPerDay: settings.maxNotifiesPerDay,
    talkCooldownMs: settings.talkCooldownMs,
    intervalMs: settings.intervalMs,
    enabled: settings.enabled,
    // 只回"填没填"，不回 key 本身：面板不需要它，浏览器里也不该留一份。
    keyConfigured: typeof settings.key === 'string' && settings.key !== '',
    idleWakeEnabled: settings.idleWakeEnabled,
    idleWakeMinutes: settings.idleWakeMinutes,
    idleWakeText: settings.idleWakeText,
  }
}

function statusView(settings, state) {
  const now = Date.now()
  return {
    todayNotified: notifiesToday(state, now),
    lastCheckAt: state.lastCheckAt === 0 ? '' : formatTime(state.lastCheckAt),
    lastWakeKind: state.lastWakeKind,
    lastError: state.lastError,
    inQuietHours: isQuietNow(settings.quietHours, now),
  }
}

/** 读完请求体；超过上限就截断并抛错，不让别人往里灌数据。 */
function readBody(req, limit) {
  return new Promise((resolve, reject) => {
    let size = 0
    const chunks = []
    req.on('data', (chunk) => {
      size += chunk.length
      if (size > limit) {
        reject(new Error(`请求体太大（上限 ${limit} 字节）`))
        req.destroy()
        return
      }
      chunks.push(chunk)
    })
    req.on('end', () => {
      resolve(Buffer.concat(chunks).toString('utf8'))
    })
    req.on('error', (error) => reject(error))
  })
}

/** 用 Node 原生响应写 JSON；HEAD 只要头不要体。 */
function respondJson(res, status, value, headOnly = false) {
  const payload = JSON.stringify(value)
  res.writeHead(status, {
    'content-type': 'application/json; charset=utf-8',
    'content-length': Buffer.byteLength(payload),
    'cache-control': 'no-store',
  })
  if (headOnly) res.end()
  else res.end(payload)
}

/**
 * 把当前设置写回 profile 里的插件配置（不改别的行，也不碰别人的字段）。
 * 拿不到 configEditor 或者被上层覆盖时抛错——调用方要照实告诉用户，不能假装存下了。
 */
async function persistConfig(ctx, settings) {
  const entry = isObject(ctx.fiber) ? ctx.fiber.entry : undefined
  if (entry === undefined) throw new Error('拿不到当前插件条目，存不进配置文件')
  const editor = typeof ctx.get === 'function' ? ctx.get('configEditor') : undefined
  if (!isObject(editor) || typeof editor.edit !== 'function') {
    throw new Error('这个 profile 里没有 configEditor，存不进配置文件')
  }
  const eventsObject = {}
  if (settings.events instanceof Map) {
    for (const [kind, on] of settings.events) eventsObject[kind] = on
  }
  const patch = {
    events: eventsObject,
    quietHours: settings.quietHours === null
      ? {}
      : { start: clockLabel(settings.quietHours).split('–')[0], end: clockLabel(settings.quietHours).split('–')[1] },
    maxNotifiesPerDay: settings.maxNotifiesPerDay,
    talkCooldownMs: settings.talkCooldownMs,
    intervalMs: settings.intervalMs,
    idleWakeEnabled: settings.idleWakeEnabled,
    idleWakeMinutes: settings.idleWakeMinutes,
    idleWakeText: settings.idleWakeText,
  }
  await editor.edit(entry, (current) => ({ ...current, ...patch }))
}

/**
 * 改运行时的这几样设置；工具和设置面板走同一段逻辑，不维护两份。
 * 返回 { changed, notes }，只动传进来的字段。
 */
function applyTune(settings, input, getRestart, state) {
  const changed = []
  const notes = []

  if (typeof input.intervalMs === 'number' && Number.isFinite(input.intervalMs)) {
    const want = Math.round(input.intervalMs)
    const next = Math.max(MIN_INTERVAL_MS, want)
    if (want !== next) notes.push(`intervalMs 最小 ${MIN_INTERVAL_MS}ms，已按 ${next} 处理`)
    if (next !== settings.intervalMs) {
      settings.intervalMs = next
      changed.push('intervalMs')
      const restart = typeof getRestart === 'function' ? getRestart() : null
      if (typeof restart === 'function') restart(next)
    }
  }

  if (typeof input.talkCooldownMs === 'number' && Number.isFinite(input.talkCooldownMs)) {
    const next = Math.max(0, Math.round(input.talkCooldownMs))
    if (next !== settings.talkCooldownMs) {
      settings.talkCooldownMs = next
      changed.push('talkCooldownMs')
    }
  }

  if (typeof input.maxNotifiesPerDay === 'number' && Number.isFinite(input.maxNotifiesPerDay)) {
    const next = Math.max(0, Math.round(input.maxNotifiesPerDay))
    if (next !== settings.maxNotifiesPerDay) {
      settings.maxNotifiesPerDay = next
      changed.push('maxNotifiesPerDay')
    }
  }

  if (typeof input.idleWakeEnabled === 'boolean') {
    if (input.idleWakeEnabled !== settings.idleWakeEnabled) {
      settings.idleWakeEnabled = input.idleWakeEnabled
      changed.push('idleWakeEnabled')
      // 刚打开时把计时起点拉到现在，否则上一次叫醒是几小时前，一开就立刻炸一条。
      if (input.idleWakeEnabled === true && isObject(state)) state.idleSince = Date.now()
    }
  }

  if (typeof input.idleWakeMinutes === 'number' && Number.isFinite(input.idleWakeMinutes)) {
    const next = Math.min(100, Math.max(1, Math.round(input.idleWakeMinutes)))
    if (next !== settings.idleWakeMinutes) {
      settings.idleWakeMinutes = next
      changed.push('idleWakeMinutes')
    }
  }

  if (typeof input.idleWakeText === 'string') {
    if (input.idleWakeText !== settings.idleWakeText) {
      settings.idleWakeText = input.idleWakeText
      changed.push('idleWakeText')
    }
  }

  if (isObject(input.events)) {
    // 只改写进来的那几个 kind，没写的保持原样——改一个不会顺手把别的清掉。
    const next = settings.events instanceof Map ? new Map(settings.events) : new Map()
    let any = false
    for (const [rawKind, rawOn] of Object.entries(input.events)) {
      const kind = String(rawKind).trim()
      if (kind === '') continue
      const on = rawOn !== false
      if (next.get(kind) !== on) {
        next.set(kind, on)
        any = true
      }
    }
    if (any) {
      settings.events = next
      changed.push('events')
    }
  }

  if (isObject(input.quietHours)) {
    const next = normalizeQuietHours(input.quietHours)
    const before = settings.quietHours === null ? '' : clockLabel(settings.quietHours)
    const after = next === null ? '' : clockLabel(next)
    if (before !== after) {
      settings.quietHours = next
      changed.push('quietHours')
    } else if (Object.keys(input.quietHours).length > 0 && next === null) {
      notes.push('quietHours 写法不对（要 "HH:MM"），没改。')
    }
  }

  return { changed, notes }
}

function registerTuneTool(ctx, settings, state, log, getRestart) {
  const tools = ctx.tools
  if (!isObject(tools) || typeof tools.register !== 'function') {
    log.warn('tools service is unavailable; tune tool not registered')
    return () => {}
  }

  const definition = {
    name: TUNE_TOOL,
    description:
      '调整「鱼的世界」提醒的运行参数，改完立刻生效、不用重启插件。'
      + '只改你传的字段，其余保持不动。'
      + '觉得太吵：加大 talkCooldownMs，或减小 maxNotifiesPerDay；想更及时：减小 intervalMs（下限 15000）。'
      + '注意：改的是运行时设置，不写回配置文件，重启后回到配置文件里的值。',
    parameters: {
      type: 'object',
      properties: {
        intervalMs: {
          type: 'number',
          description: '多久轮询一次（毫秒），最小 15000。改它会立刻重排定时器。',
        },
        talkCooldownMs: {
          type: 'number',
          description: '同一个人连续当面说话，多久才再叫醒一次（毫秒）。0 = 不冷却，每条都叫醒。',
        },
        maxNotifiesPerDay: {
          type: 'number',
          description: '一天最多叫醒几次；0 = 只注入不叫醒。',
        },
        events: {
          type: 'object',
          description: '按事件类型开关，例如 {"done":true,"arrive":true}。只改写进来的那几个 kind。',
        },
        quietHours: {
          type: 'object',
          description: '免打扰时段，例如 {"start":"23:00","end":"07:00"}；传 {} 清掉。',
        },
      },
      additionalProperties: false,
    },
    output: {
      schema: {
        type: 'object',
        properties: {
          changed: { type: 'array', items: { type: 'string' }, description: '这次真的被改了的字段。' },
          intervalMs: { type: 'number', description: '改完之后的轮询间隔。' },
          talkCooldownMs: { type: 'number', description: '改完之后的 talk 冷却。' },
          maxNotifiesPerDay: { type: 'number', description: '改完之后的每日上限。' },
          note: { type: 'string', description: '补充说明（比如被下限钳住了）或空串。' },
        },
        additionalProperties: false,
      },
      render(_args, value) {
        return renderTune(value)
      },
    },
    async execute(args) {
      const input = isObject(args) ? args : {}
      const { changed, notes } = applyTune(settings, input, getRestart, state)

      if (changed.length === 0 && notes.length === 0) notes.push('参数没变，什么都没动。')
      log.info(`tuned: ${changed.length === 0 ? 'no change' : changed.join(', ')}`)

      return {
        changed,
        intervalMs: settings.intervalMs,
        talkCooldownMs: settings.talkCooldownMs,
        maxNotifiesPerDay: settings.maxNotifiesPerDay,
        note: notes.join('；'),
      }
    },
  }

  try {
    return tools.register(definition)
  } catch (error) {
    log.warn(`tune tool registration failed: ${describeError(error)}`)
    return () => {}
  }
}

function renderTune(value) {
  try {
    const report = isObject(value) ? value : {}
    const changed = Array.isArray(report.changed) ? report.changed : []
    const lines = [
      changed.length === 0 ? '没有改动。' : `已改：${changed.join('、')}`,
      `轮询间隔：${typeof report.intervalMs === 'number' ? report.intervalMs : 0} ms`,
      `当面说话冷却：${typeof report.talkCooldownMs === 'number' ? report.talkCooldownMs : 0} ms（0 = 不冷却）`,
      `每日叫醒上限：${typeof report.maxNotifiesPerDay === 'number' ? report.maxNotifiesPerDay : 0} 次（0 = 只注入）`,
    ]
    if (typeof report.note === 'string' && report.note !== '') lines.push(report.note)
    lines.push('这些是运行时设置，重启后会回到配置文件里的值。')
    return [{ type: 'text', text: lines.join('\n') }]
  } catch {
    return [{ type: 'text', text: '调参结果读不出来；可以再调一次，或者用提醒状态工具看一眼。' }]
  }
}

function registerStatusTool(ctx, settings, state, log) {
  const tools = ctx.tools
  if (!isObject(tools) || typeof tools.register !== 'function') {
    log.warn('tools service is unavailable; status tool not registered')
    return () => {}
  }

  const definition = {
    name: STATUS_TOOL,
    description:
      '查看「鱼的世界」提醒的当前状态：是否启用、密钥是否已配置、轮询间隔、基准 cursor、'
      + '上次检查时间与错误、今天已叫醒几次、最近一次叫醒、去重缓存条数。'
      + '只读，不发网络请求；怀疑提醒没在工作时先看这里。',
    parameters: {
      type: 'object',
      properties: {},
      additionalProperties: false,
    },
    output: {
      schema: {
        type: 'object',
        properties: {
          enabled: { type: 'boolean', description: '轮询是否启用。' },
          keyConfigured: { type: 'boolean', description: '是否配置了 key（不会回显 key 本身）。' },
          intervalMs: { type: 'number', description: '实际使用的轮询间隔（毫秒）。' },
          baseCursor: { type: 'string', description: '钉住的 cursor 基准点；空串表示还没钉住。' },
          lastCheckAt: { type: 'string', description: '上次成功检查的本地时间；空串表示还没成功过。' },
          lastError: { type: 'string', description: '上次失败原因；空串表示最近一次检查成功。' },
          lastSkipped: { type: 'number', description: '服务端上一次没给出来的旧事件条数（很久没问时只给最近 50 条）；0 = 没跳过。' },
          todayNotified: { type: 'number', description: '今天已经叫醒过几次（按本地日归零）。' },
          maxNotifiesPerDay: { type: 'number', description: '每天叫醒上限；0 表示只注入不叫醒。' },
          lastWakeKind: { type: 'string', description: '最近一次叫醒携带的事件类型，逗号分隔；空串表示还没叫醒过。' },
          lastWakeAt: { type: 'string', description: '最近一次叫醒的本地时间；空串表示还没叫醒过。' },
          seenCount: { type: 'number', description: '去重缓存里现有的事件指纹条数（上限 200）。' },
          targetMode: { type: 'string', description: '投递目标：all = 所有会话都收到（没填 wakeSessions）；selected = 只发给 wakeSessions 名单里的。' },
          talkCooldownMs: { type: 'number', description: '同一个人连续当面说话，多久才再叫醒一次（毫秒）；0 = 不冷却。' },
          events: {
            type: 'array',
            description: '现在开着的事件类型。arrive / done 默认关，免得日常流水刷屏；配置的 events 里写 true 就会出现在这里。',
            items: { type: 'string' },
          },
          quietHours: { type: 'string', description: '免打扰时段，形如 "23:00–07:00"；空串表示没设。' },
          inQuietHours: { type: 'boolean', description: '现在是不是正处在免打扰时段里（这时只注入不叫醒）。' },
          sessions: {
            type: 'array',
            description: '当前所有顶层会话，以及按现在的配置会不会被叫醒。要只叫某一个，把它的 id 抄进配置的 wakeSessions。',
            items: {
              type: 'object',
              properties: {
                id: { type: 'string', description: '会话 id，配置里填的就是这个。' },
                willWake: { type: 'boolean', description: '按现在的配置，这个会话会不会收到提醒。' },
              },
              additionalProperties: false,
            },
          },
        },
        additionalProperties: false,
      },
      render(_args, value) {
        return renderStatus(value)
      },
    },
    async execute() {
      try {
        return snapshot(ctx, settings, state)
      } catch (error) {
        log.warn(`status snapshot failed: ${describeError(error)}`)
        return fallbackSnapshot(settings)
      }
    },
  }

  try {
    return tools.register(definition)
  } catch (error) {
    log.warn(`status tool registration failed: ${describeError(error)}`)
    return () => {}
  }
}

function snapshot(ctx, settings, state) {
  const now = Date.now()
  const skip = new Set(settings.skipSessions)
  const want = new Set(settings.wakeSessions)
  const sessions = listRoots(ctx).map((agent) => {
    const id = typeof agent.id === 'string' ? agent.id : ''
    const willWake = (id === '' || !skip.has(id)) && (want.size === 0 || (id !== '' && want.has(id)))
    return { id, willWake }
  })
  return {
    enabled: settings.enabled,
    keyConfigured: settings.key !== '',
    intervalMs: settings.intervalMs,
    baseCursor: state.baseCursor,
    lastCheckAt: state.lastCheckAt === 0 ? '' : formatTime(state.lastCheckAt),
    lastError: state.lastError,
    lastSkipped: state.lastSkipped,
    todayNotified: notifiesToday(state, now),
    maxNotifiesPerDay: settings.maxNotifiesPerDay,
    lastWakeKind: state.lastWakeKind,
    lastWakeAt: state.lastWakeAt === 0 ? '' : formatTime(state.lastWakeAt),
    seenCount: state.seen.length,
    targetMode: want.size === 0 ? 'all' : 'selected',
    talkCooldownMs: settings.talkCooldownMs,
    events: eventSwitchView(settings),
    quietHours: settings.quietHours === null ? '' : clockLabel(settings.quietHours),
    inQuietHours: isQuietNow(settings.quietHours, now),
    sessions,
  }
}

function fallbackSnapshot(settings) {
  return {
    enabled: settings.enabled,
    keyConfigured: settings.key !== '',
    intervalMs: settings.intervalMs,
    baseCursor: '',
    lastCheckAt: '',
    lastError: '读取状态失败',
    todayNotified: 0,
    maxNotifiesPerDay: settings.maxNotifiesPerDay,
    lastWakeKind: '',
    lastWakeAt: '',
    seenCount: 0,
    targetMode: settings.wakeSessions.length === 0 ? 'all' : 'selected',
    talkCooldownMs: settings.talkCooldownMs,
    events: eventSwitchView(settings),
    quietHours: settings.quietHours === null ? '' : clockLabel(settings.quietHours),
    inQuietHours: isQuietNow(settings.quietHours, Date.now()),
    sessions: [],
  }
}

function renderStatus(value) {
  try {
    const report = isObject(value) ? value : {}
    const cap = typeof report.maxNotifiesPerDay === 'number' ? report.maxNotifiesPerDay : 0
    const used = typeof report.todayNotified === 'number' ? report.todayNotified : 0
    const seen = typeof report.seenCount === 'number' ? report.seenCount : 0
    const sessions = Array.isArray(report.sessions) ? report.sessions : []

    const lines = [
      `鱼的世界提醒：${report.enabled === true ? '已启用' : '已停用（不轮询）'}`,
      `密钥：${report.keyConfigured === true ? '已配置' : '未配置（提醒不会启动）'}`,
      `轮询间隔：${typeof report.intervalMs === 'number' ? report.intervalMs : 0} ms`,
      `基准 cursor：${typeof report.baseCursor === 'string' && report.baseCursor !== '' ? report.baseCursor : '还没钉住（下一次检查只拿基准点）'}`,
      `上次检查：${typeof report.lastCheckAt === 'string' && report.lastCheckAt !== '' ? report.lastCheckAt : '还没成功检查过'}`,
      `今天已叫醒：${used}/${cap} 次${cap === 0 ? '（0 = 只注入，不叫醒）' : ''}`,
      `最近叫醒：${typeof report.lastWakeKind === 'string' && report.lastWakeKind !== '' ? `${report.lastWakeKind} @ ${report.lastWakeAt}` : '还没有'}`,
      `投递目标：${report.targetMode === 'selected' ? '只发给 wakeSessions 名单里的会话' : '所有会话（没填 wakeSessions，一个都不会漏）'}`,
      `当面说话冷却：${typeof report.talkCooldownMs === 'number' && report.talkCooldownMs > 0 ? `${Math.round(report.talkCooldownMs / 60000)} 分钟内同一个人的 talk 只叫醒一次，其余注入` : '关闭（每条 talk 都叫醒）'}`,
    ]

    if (sessions.length > 0) {
      lines.push('会话（→ 会叫醒 / · 不会）：')
      for (const item of sessions) {
        const id = isObject(item) && typeof item.id === 'string' && item.id !== '' ? item.id : '(拿不到 id)'
        const wake = isObject(item) && item.willWake === true
        lines.push(`  ${wake ? '→' : '·'} ${id}`)
      }
      lines.push('  只叫其中一个：把那个 id 抄进配置的 wakeSessions；不想被打扰的抄进 skipSessions。')
    }

    lines.push(`去重缓存：${seen}/${MAX_SEEN} 条事件指纹`)
    const skipped = typeof report.lastSkipped === 'number' ? report.lastSkipped : 0
    lines.push(`跳过的旧事件：${skipped === 0 ? '无' : `${skipped} 条（服务端只给最近 50 条，更早的没给）`}`)

    const events = Array.isArray(report.events) ? report.events : []
    lines.push(`提醒哪些事件：${events.length === 0 ? '（全部关掉了）' : events.join('、')}`)
    const quiet = typeof report.quietHours === 'string' ? report.quietHours : ''
    if (quiet !== '') {
      lines.push(`免打扰：${quiet}${report.inQuietHours === true ? '（现在就在里面，只注入不叫醒）' : ''}`)
    }

    lines.push(`上次错误：${typeof report.lastError === 'string' && report.lastError !== '' ? report.lastError : '无'}`)

    // 《鱼的世界插件开发者规范》(2026-11) 六-6：显著位置保留名称、官网、插件页入口，注明非官方。
    lines.push('—— 非官方插件 · 鱼的世界 https://yuyuworld.app · 插件页 https://yuyuworld.app/plugins')

    return [{ type: 'text', text: lines.join('\n') }]
  } catch {
    return [{ type: 'text', text: '提醒状态读不出来；可以稍后再试。' }]
  }
}

/* ------------------------------------------------------- 可选：提示注入 */

/** 拿得到 systemPrompt 就注册一行运行时上下文；拿不到安静跳过（不是硬依赖）。 */
function registerHint(ctx, state, log) {
  let systemPrompt
  try {
    systemPrompt = typeof ctx.get === 'function' ? ctx.get('systemPrompt') : undefined
  } catch {
    systemPrompt = undefined
  }

  if (!isObject(systemPrompt) || typeof systemPrompt.context !== 'function') {
    log.info('systemPrompt unavailable; prompt hint disabled')
    return () => {}
  }

  return systemPrompt.context({
    name: PLUGIN_NAME,
    order: CONTEXT_ORDER,
    text: () => hintText(state),
  })
}

function hintText(state) {
  try {
    const hint = state.hint
    if (!isObject(hint) || typeof hint.text !== 'string' || typeof hint.at !== 'number') return ''
    if (Date.now() - hint.at > HINT_TTL_MS) return ''
    return hint.text
  } catch {
    return ''
  }
}

/* ------------------------------------------------------------ 去重与指纹 */

/**
 * 把「配置说开着、而且还没见过」的事件挑出来，按“叫醒 / 只注入”分组。
 * 开关看 settings.events（没写的 kind 走 DEFAULT_EVENT_SWITCH，再没有就默认开）；
 * 同一批里重复的指纹也只算一次。
 */
function collectFresh(raw, state, settings) {
  const wake = []
  const quiet = []
  const batch = new Set()

  for (const item of raw) {
    try {
      if (!isObject(item)) continue
      const kind = String(item.kind ?? '')
      if (kind === '') continue
      if (!eventEnabled(settings, kind)) continue

      const fingerprint = fingerprintOf(item)
      if (state.seenSet.has(fingerprint) || batch.has(fingerprint)) continue
      batch.add(fingerprint)

      const entry = {
        kind,
        fingerprint,
        text: typeof item.text === 'string' ? item.text : '',
        time: itemTime(item),
        speaker: typeof item.from === 'string' && item.from !== '' ? item.from : speakerOf(item.text),
      }
      if (eventWakes(kind)) wake.push(entry)
      else quiet.push(entry)
    } catch {
      // 单条坏数据不影响整批
    }
  }

  return { wake, quiet }
}

/**
 * 事件指纹：kind + 分钟刻度 + 说话者的 FNV-1a，再带上基准串长度降低碰撞。
 * 32 位够做“同一条事件”的判等，不需要密码学强度（旧 poller 的做法）。
 *
 * 为什么不把正文算进去：通知端点的正文是**累计快照**——同一个人同一分钟里
 * 「说了 17 句话」→「说了 18 句话」，每半分钟变长一次。把它们当成不同事件去
 * 叫醒，一场八轮对话就能烧掉八九次叫醒额度，每次还各占一个 Agent 轮次。
 *
 * 也不拿 `t` 当刻度：`t` 是毫秒时间戳，每条播报都不同，用它等于没去重。
 * 刻度统一走 stampOf()（分钟 + 日期），同一分钟里同一个人的连续播报只算一条。
 * 抠不出说话者的事件（比如 note）退回用正文前 40 字，免得它们被合并成一条。
 */
function fingerprintOf(item) {
  const kind = String(item.kind ?? '')
  const stamp = stampOf(item)
  const text = typeof item.text === 'string' ? item.text : ''
  const speaker = typeof item.from === 'string' && item.from !== '' ? item.from : speakerOf(text)
  const basis = speaker === ''
    ? `${kind}|${stamp}|${collapseWhitespace(text).slice(0, 40)}`
    : `${kind}|${stamp}|${speaker}`
  return `${fnv1a(basis)}-${basis.length}`
}

/**
 * 判等用的时间刻度：**分钟**，不是 `t` 的毫秒。
 * 事件形如 {kind, t: 1794729146296, from: "小汐#7116", time: "15:52", text}。
 * 用 `t` 补上日期，免得今天和明天的「15:52」撞成同一条。
 */
function stampOf(item) {
  const minute = typeof item.time === 'string' ? item.time.trim() : ''
  const ms = typeof item.t === 'number' ? item.t : 0
  if (minute === '') return String(item.t ?? '')
  if (ms <= 0) return minute
  const date = new Date(ms)
  const two = (value) => String(value).padStart(2, '0')
  return `${date.getFullYear()}-${two(date.getMonth() + 1)}-${two(date.getDate())} ${minute}`
}

/** 从事件正文里抠「名字#编号」的编号；`from` 缺了才用它。 */
function speakerOf(text) {
  if (typeof text !== 'string') return ''
  const match = /#(\d+)/.exec(text)
  return match === null ? '' : match[1]
}

/** 32 位 FNV-1a。 */
function fnv1a(text) {
  let hash = 0x811c9dc5
  for (let index = 0; index < text.length; index += 1) {
    hash ^= text.charCodeAt(index)
    hash = Math.imul(hash, 0x01000193) >>> 0
  }
  return hash.toString(16).padStart(8, '0')
}

/** 送成功之后才记账；FIFO 上限 200。 */
function rememberAll(state, entries) {
  for (const entry of entries) remember(state, entry.fingerprint)
}

function remember(state, fingerprint) {
  if (typeof fingerprint !== 'string' || fingerprint === '') return
  if (state.seenSet.has(fingerprint)) return
  state.seen.push(fingerprint)
  state.seenSet.add(fingerprint)
  state.seenAt.set(fingerprint, Date.now())
  while (state.seen.length > MAX_SEEN) {
    const oldest = state.seen.shift()
    if (typeof oldest === 'string') {
      state.seenSet.delete(oldest)
      state.seenAt.delete(oldest)
    }
  }
}

/**
 * seen 落盘 —— 2026-11-16 加。
 *
 * 起因：`seen` 只在内存里，插件一重载（DSH 重启、改文件触发 HMR）就归零，
 * 于是服务端最近 50 条历史事件被当成新事件重推一遍。11-16 凌晨亲自撞见两次。
 *
 * 存什么：只有指纹和它被记下的时间，**不含正文**。24 小时后自然过期。
 * 存在 logPath 同目录的 `.fishworld-seen.json`；落盘失败不影响提醒本身。
 */
const SEEN_TTL_MS = 24 * 60 * 60 * 1000

function seenFilePath(logPath) {
  if (typeof logPath !== 'string' || logPath.trim() === '') return ''
  const full = logPath.trim().replace(/\\/g, '/')
  const cut = full.lastIndexOf('/')
  if (cut <= 0) return ''
  return `${full.slice(0, cut)}/.fishworld-seen.json`
}

function loadSeen(state, log) {
  const file = state.seenFile
  if (file === '') return
  try {
    if (!existsSync(file)) return
    const raw = JSON.parse(readFileSync(file, 'utf8'))
    if (!isObject(raw)) return
    const now = Date.now()
    let kept = 0
    for (const [fingerprint, stamp] of Object.entries(raw)) {
      if (typeof fingerprint !== 'string' || fingerprint === '') continue
      if (typeof stamp !== 'number' || now - stamp > SEEN_TTL_MS) continue
      if (state.seenSet.has(fingerprint)) continue
      state.seen.push(fingerprint)
      state.seenSet.add(fingerprint)
      state.seenAt.set(fingerprint, stamp)
      kept++
    }
    while (state.seen.length > MAX_SEEN) {
      const oldest = state.seen.shift()
      if (typeof oldest === 'string') {
        state.seenSet.delete(oldest)
        state.seenAt.delete(oldest)
      }
    }
    log.info(`seen restored: ${kept} fingerprint(s) from ${file}`)
  } catch (error) {
    log.warn(`seen restore failed: ${describeError(error)}`)
  }
}

function saveSeen(state) {
  const file = state.seenFile
  if (file === '') return
  try {
    const out = {}
    for (const fingerprint of state.seen) {
      const stamp = state.seenAt.get(fingerprint)
      out[fingerprint] = typeof stamp === 'number' ? stamp : Date.now()
    }
    writeFileSync(file, JSON.stringify(out), 'utf8')
  } catch (error) {
    // 落盘失败不影响提醒本身；下一轮还会再试。
    void error
  }
}

/* ---------------------------------------------------------------- 小工具 */

function createState(settings) {
  return {
    /** 第一次拿到后就钉住，不再跟着响应里的 cursor 走。 */
    baseCursor: settings.baseCursor,
    /** 指纹数组（FIFO）与它的 Set 索引，两个一起维护。 */
    seen: [],
    seenSet: new Set(),
    /** 指纹 → 记下的毫秒时间；落盘和 24 小时过期用。 */
    seenAt: new Map(),
    /** seen 落盘路径；空串表示不落盘（没配 logPath 时）。 */
    seenFile: '',
    /** 本地日计数。 */
    dayKey: '',
    dayCount: 0,
    lastCheckAt: 0,
    lastError: '',
    lastSkipped: 0,
    lastWakeKind: '',
    lastWakeAt: 0,
    /** 上一次叫醒之后安静了多久的起点（毫秒）；空闲唤醒按它算，正常消息叫醒也会把它推到现在。 */
    idleSince: Date.now(),
    /** 降级注入后给 systemPrompt 的一行提示：{ at, text } 或 null。 */
    hint: null,
    /** 每个说话者上次被叫醒的毫秒时间，talk 冷却用；不落盘，重载清零。 */
    talkCooldown: new Map(),
  }
}

function normalizeConfig(config) {
  const source = isObject(config) ? config : {}

  const key = typeof source.key === 'string' ? source.key.trim() : ''
  const intervalMs = typeof source.intervalMs === 'number' && Number.isFinite(source.intervalMs)
    ? Math.max(MIN_INTERVAL_MS, Math.round(source.intervalMs))
    : DEFAULT_INTERVAL_MS
  const baseCursor = typeof source.baseCursor === 'string' ? source.baseCursor.trim() : ''
  const enabled = source.enabled !== false
  const maxNotifiesPerDay = typeof source.maxNotifiesPerDay === 'number' && Number.isFinite(source.maxNotifiesPerDay)
    ? Math.max(0, Math.round(source.maxNotifiesPerDay))
    : DEFAULT_MAX_NOTIFIES_PER_DAY
  const logPath = typeof source.logPath === 'string' ? source.logPath.trim() : ''
  const wakeSessions = normalizeIds(source.wakeSessions)
  const skipSessions = normalizeIds(source.skipSessions)
  const talkCooldownMs = typeof source.talkCooldownMs === 'number' && Number.isFinite(source.talkCooldownMs)
    ? Math.max(0, Math.round(source.talkCooldownMs))
    : DEFAULT_TALK_COOLDOWN_MS
  const events = normalizeEvents(source.events)
  const quietHours = normalizeQuietHours(source.quietHours)
  const idleWakeEnabled = source.idleWakeEnabled === true
  const idleWakeMinutes = typeof source.idleWakeMinutes === 'number' && Number.isFinite(source.idleWakeMinutes)
    ? Math.min(100, Math.max(1, Math.round(source.idleWakeMinutes)))
    : 60
  const idleWakeText = typeof source.idleWakeText === 'string' ? source.idleWakeText : ''

  return {
    key, intervalMs, baseCursor, enabled, maxNotifiesPerDay, logPath,
    wakeSessions, skipSessions, talkCooldownMs, events, quietHours,
    idleWakeEnabled, idleWakeMinutes, idleWakeText,
  }
}

/**
 * 每个 kind 的开关。没写在配置里的 kind 用 DEFAULT_EVENT_SWITCH 里的默认值，
 * 那张表里也没有的（世界以后新加的）默认开——宁可多叫一次，也别悄悄吞掉。
 */
function normalizeEvents(value) {
  const out = new Map()
  if (!isObject(value)) return out
  for (const [rawKind, rawOn] of Object.entries(value)) {
    const kind = String(rawKind).trim()
    if (kind === '') continue
    out.set(kind, rawOn !== false)
  }
  return out
}

/** 这个 kind 要不要提醒。 */
function eventEnabled(settings, kind) {
  const explicit = settings.events instanceof Map ? settings.events.get(kind) : undefined
  if (typeof explicit === 'boolean') return explicit
  if (Object.prototype.hasOwnProperty.call(DEFAULT_EVENT_SWITCH, kind)) return DEFAULT_EVENT_SWITCH[kind]
  return true
}

/** 这个 kind 要不要叫醒（开关关掉的连注入都不做，所以这里只在开着时才问）。 */
function eventWakes(kind) {
  if (Object.prototype.hasOwnProperty.call(DEFAULT_EVENT_WAKE, kind)) return DEFAULT_EVENT_WAKE[kind]
  // 世界以后新加的 kind：先按“只注入”处理，等它出现在 kinds 列表里再决定。
  return false
}

/**
 * 给状态工具看的开关表：只列开着的 kind（数组——DSH 的 schema 不接受布尔值对象）。
 * 顺序先按 DEFAULT_EVENT_SWITCH 的书写顺序（好认），再把配置里多写的按字母补在后面。
 */
function eventSwitchView(settings) {
  const order = Object.keys(DEFAULT_EVENT_SWITCH)
  const extra = []
  if (settings.events instanceof Map) {
    for (const kind of settings.events.keys()) {
      if (!order.includes(kind) && !extra.includes(kind)) extra.push(kind)
    }
  }
  extra.sort()
  return [...order, ...extra].filter((kind) => eventEnabled(settings, kind))
}

/** {"start":"23:00","end":"07:00"} → { startMin, endMin }；没填或写坏了返回 null。 */
function normalizeQuietHours(value) {
  if (!isObject(value)) return null
  const startMin = parseClock(value.start)
  const endMin = parseClock(value.end)
  if (startMin === null || endMin === null || startMin === endMin) return null
  return { startMin, endMin }
}

/** "23:00" / "7:05" / "23:00:00" → 分钟数；写坏了返回 null。 */
function parseClock(value) {
  if (typeof value !== 'string') return null
  const m = /^(\d{1,2}):(\d{2})(?::\d{2})?$/.exec(value.trim())
  if (m === null) return null
  const hour = Number(m[1])
  const minute = Number(m[2])
  if (!Number.isFinite(hour) || !Number.isFinite(minute)) return null
  if (hour > 23 || minute > 59) return null
  return hour * 60 + minute
}

/** 现在是不是在免打扰时段里。跨午夜（start > end）也认。 */
function isQuietNow(quietHours, now) {
  if (quietHours === null) return false
  const date = new Date(now)
  const minuteOfDay = date.getHours() * 60 + date.getMinutes()
  const { startMin, endMin } = quietHours
  if (startMin < endMin) return minuteOfDay >= startMin && minuteOfDay < endMin
  return minuteOfDay >= startMin || minuteOfDay < endMin
}

/** 免打扰时段写成给人看的样子："23:00–07:00"。 */
function clockLabel(quietHours) {
  if (quietHours === null) return ''
  const fmt = (min) => `${String(Math.floor(min / 60)).padStart(2, '0')}:${String(min % 60).padStart(2, '0')}`
  return `${fmt(quietHours.startMin)}–${fmt(quietHours.endMin)}`
}

/** 把配置里的字符串数组清成去重、去空白的 id 列表；不是数组就当没填。 */
function normalizeIds(value) {
  if (!Array.isArray(value)) return []
  const out = []
  for (const item of value) {
    if (typeof item !== 'string') continue
    const id = item.trim()
    if (id !== '' && out.indexOf(id) === -1) out.push(id)
  }
  return out
}

/** 当天叫醒次数；跨本地日自动归零（不落盘，重启也归零）。 */
function notifiesToday(state, now) {
  return state.dayKey === dayKeyOf(now) ? state.dayCount : 0
}

function dayKeyOf(timestamp) {
  const date = new Date(timestamp)
  const two = (value) => String(value).padStart(2, '0')
  return `${date.getFullYear()}-${two(date.getMonth() + 1)}-${two(date.getDate())}`
}

function uniqueKinds(entries) {
  const kinds = []
  for (const entry of entries) {
    if (!kinds.includes(entry.kind)) kinds.push(entry.kind)
  }
  return kinds.join(',')
}

function itemTime(item) {
  const value = item.time ?? item.t
  if (typeof value === 'string' && value !== '') return value
  if (typeof value === 'number' && Number.isFinite(value)) return formatTime(value)
  return formatTime(Date.now())
}

function formatTime(timestamp) {
  if (typeof timestamp !== 'number' || !Number.isFinite(timestamp)) return ''
  const date = new Date(timestamp)
  const two = (value) => String(value).padStart(2, '0')
  return `${date.getFullYear()}-${two(date.getMonth() + 1)}-${two(date.getDate())} `
    + `${two(date.getHours())}:${two(date.getMinutes())}:${two(date.getSeconds())}`
}

function collapseWhitespace(text) {
  if (typeof text !== 'string') return ''
  return text.replace(/\s+/g, ' ').trim()
}

function isObject(value) {
  return value !== null && typeof value === 'object'
}

function describeError(error) {
  try {
    if (isObject(error) && typeof error.message === 'string') return error.message
    return String(error)
  } catch {
    return 'unknown error'
  }
}

/* ------------------------------------------------------------------ 网络 */

/**
 * GET 一个 JSON。用 node:https 而不是 fetch：fetch 走 undici 的全局 dispatcher，
 * 在配了 HTTP_PROXY 的机器上会被代理拦成空响应（旧插件踩过）。
 *
 * 永远 resolve `{ status, data, parseError? }` 而不是因为非 2xx 抛错；只有真正的
 * 传输错误才 reject。调用方按 status 分支处理。
 */
function getJson(url, key, redirectsLeft = MAX_REDIRECTS) {
  return new Promise((resolve, reject) => {
    let settled = false
    const settle = (fn, value) => {
      if (settled) return
      settled = true
      fn(value)
    }

    let req
    try {
      req = https.request(
        url,
        {
          method: 'GET',
          headers: {
            authorization: `Bearer ${key}`,
            accept: 'application/json',
          },
        },
        (res) => {
          const status = typeof res.statusCode === 'number' ? res.statusCode : 0
          const location = isObject(res.headers) && typeof res.headers.location === 'string'
            ? res.headers.location
            : ''

          if (status >= 300 && status < 400 && location !== '' && redirectsLeft > 0) {
            try {
              safeCall(() => res.resume?.())
              const next = new URL(location, url).toString()
              getJson(next, key, redirectsLeft - 1).then(
                (value) => settle(resolve, value),
                (error) => settle(reject, error),
              )
            } catch (error) {
              settle(reject, error)
            }
            return
          }

          let body = ''
          let bytes = 0
          res.setEncoding('utf8')
          res.on('data', (chunk) => {
            bytes += Buffer.byteLength(chunk)
            if (bytes > MAX_RESPONSE_BYTES) {
              safeCall(() => req.destroy(new Error('response too large')))
              return
            }
            body += chunk
          })
          res.on('end', () => {
            if (body === '') {
              settle(resolve, { status, data: undefined, parseError: 'empty response' })
              return
            }
            try {
              settle(resolve, { status, data: JSON.parse(body) })
            } catch {
              settle(resolve, {
                status,
                data: undefined,
                parseError: `bad json (${status}): ${body.slice(0, 120)}`,
              })
            }
          })
          res.on('error', (error) => settle(reject, error))
        },
      )
    } catch (error) {
      settle(reject, error)
      return
    }

    req.setTimeout(HTTP_TIMEOUT_MS, () => {
      safeCall(() => req.destroy(new Error('timeout')))
    })
    req.on('error', (error) => settle(reject, error))
    req.end()
  })
}

/* -------------------------------------------------------------- 生命周期 */

/**
 * 把一次注册包进 ctx.effect，并保证：
 *   - install 抛错只记日志，不打断 apply；
 *   - 返回的清理函数一定会被 effect 收走。
 */
function installEffect(ctx, install, log) {
  if (!isObject(ctx) || typeof ctx.effect !== 'function') {
    // 没有 effect 的宿主：至少把功能装上，代价是卸载可能不及时。
    try {
      const dispose = install()
      // 这里不能调用 dispose：没有 effect 就没有卸载时机，立刻调用等于当场注销。
      void dispose
    } catch (error) {
      log.warn(`install failed: ${describeError(error)}`)
    }
    return
  }

  try {
    ctx.effect(() => {
      try {
        const dispose = install()
        return typeof dispose === 'function' ? dispose : () => {}
      } catch (error) {
        log.warn(`install failed: ${describeError(error)}`)
        return () => {}
      }
    })
  } catch (error) {
    log.warn(`effect registration failed: ${describeError(error)}`)
  }
}

/** 宿主有 ctx.setInterval 就用它（自带清理）；否则退回全局定时器并 unref。 */
function startInterval(ctx, callback, intervalMs) {
  try {
    if (typeof ctx.setInterval === 'function') return ctx.setInterval(callback, intervalMs)
  } catch {
    // 继续尝试下一种
  }

  const handle = setInterval(callback, intervalMs)
  if (isObject(handle) && typeof handle.unref === 'function') handle.unref()
  return () => clearInterval(handle)
}

/**
 * 日志：优先用宿主 logger（ctx.logger 可能是函数，也可能是对象），
 * 同时可选追加到 logPath。写不出去就安静放弃，绝不因为日志失败影响主流程。
 */
function createLogger(ctx, logPath) {
  let logger
  try {
    if (isObject(ctx) && typeof ctx.logger === 'function') logger = ctx.logger(PLUGIN_NAME)
    else if (isObject(ctx) && isObject(ctx.logger)) logger = ctx.logger
  } catch {
    logger = undefined
  }

  const emit = (level, message) => {
    const line = `[${PLUGIN_NAME}] ${message}`
    try {
      const method = isObject(logger) && typeof logger[level] === 'function' ? logger[level] : undefined
      if (method !== undefined) method.call(logger, line)
      else if (level === 'warn' && typeof console !== 'undefined' && typeof console.warn === 'function') console.warn(line)
    } catch {
      // 日志失败不影响主流程
    }

    if (logPath !== '') {
      try {
        void appendFile(logPath, `${new Date().toISOString()} ${line}\n`, 'utf8').catch(() => {})
      } catch {
        // 路径不可写就算了
      }
    }
  }

  return {
    info: (message) => emit('info', message),
    warn: (message) => emit('warn', message),
  }
}

function safeCall(fn) {
  try {
    if (typeof fn === 'function') fn()
  } catch {
    // 清理失败不影响卸载
  }
}
