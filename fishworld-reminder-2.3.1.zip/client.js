/**
 * 鱼的世界 · 提醒 —— 设置面板（Client 半）
 *
 * 挂在「设置 → 插件」里的一个 tab 上。它自己不算逻辑：
 * 读写都打 Host 的同一个路由（/fishworld-reminder/settings），
 * 那段逻辑和 fishworld_reminder_tune 工具共用 applyTune，不维护两份。
 */
window.__ModuleLoader__.load({
  id: '@local/fishworld-reminder',
  factory(require) {
    const React = require('react')
    const h = React.createElement
    const { useCallback, useEffect, useState } = React

    const ENDPOINT = '/fishworld-reminder/settings'

    /** 面板上列出来的事件类型；顺序和 Host 端 DEFAULT_EVENT_SWITCH 一致。 */
    const KIND_ROWS = [
      { kind: 'talk', title: '有人当面说话', hint: '一场话只叫醒一次，之后只注入正文。' },
      { kind: 'message', title: '好友发来消息', hint: '' },
      { kind: 'note', title: '留言', hint: '' },
      { kind: 'friend_request', title: '好友申请', hint: '一天内不处理就失效。' },
      { kind: 'doorbell', title: '有人按门铃', hint: '几分钟内不开就走。' },
      { kind: 'work', title: '打工来活了', hint: '几分钟内不处理就扣工钱，所以这类一定叫醒。' },
      { kind: 'arrive', title: '到了某个地方', hint: '日常流水，默认关着。' },
      { kind: 'done', title: '做完了一件事', hint: '日常流水，默认关着。' },
    ]

    const styles = {
      page: {
        padding: '20px 4px 32px',
        display: 'flex',
        flexDirection: 'column',
        gap: 20,
        color: 'var(--dsw-alias-label-primary)',
        maxWidth: 720,
      },
      section: { display: 'flex', flexDirection: 'column', gap: 10 },
      sectionTitle: { fontSize: 14, fontWeight: 600 },
      sectionHint: { fontSize: 12, color: 'var(--dsw-alias-label-secondary)', lineHeight: 1.6 },
      row: {
        display: 'flex',
        alignItems: 'flex-start',
        gap: 10,
        padding: '10px 12px',
        borderRadius: 8,
        background: 'var(--dsw-alias-bg-layer-1)',
        border: '1px solid var(--dsw-alias-border-l1)',
      },
      rowText: { display: 'flex', flexDirection: 'column', gap: 2, minWidth: 0 },
      rowTitle: { fontSize: 13 },
      rowHint: { fontSize: 12, color: 'var(--dsw-alias-label-secondary)', lineHeight: 1.5 },
      checkbox: { marginTop: 2, cursor: 'pointer', flex: 'none' },
      statLine: { fontSize: 12, color: 'var(--dsw-alias-label-secondary)', lineHeight: 1.8 },
      inline: { display: 'flex', alignItems: 'center', gap: 8, flexWrap: 'wrap' },
      time: {
        fontSize: 13,
        padding: '4px 8px',
        borderRadius: 6,
        color: 'var(--dsw-alias-label-primary)',
        background: 'var(--dsw-alias-bg-layer-1)',
        border: '1px solid var(--dsw-alias-border-l2)',
      },
      button: {
        fontSize: 13,
        padding: '5px 14px',
        borderRadius: 6,
        cursor: 'pointer',
        color: 'var(--dsw-alias-label-primary)',
        background: 'var(--dsw-alias-bg-layer-2)',
        border: '1px solid var(--dsw-alias-border-l2)',
      },
      buttonPrimary: {
        fontSize: 13,
        padding: '5px 14px',
        borderRadius: 6,
        cursor: 'pointer',
        color: '#fff',
        background: 'var(--dsw-alias-brand-primary)',
        border: '1px solid var(--dsw-alias-brand-primary)',
      },
      ok: { fontSize: 12, color: 'var(--dsw-alias-state-success-primary)' },
      warn: { fontSize: 12, color: 'var(--dsw-alias-state-warn-primary)' },
      error: { fontSize: 12, color: 'var(--dsw-alias-state-error-primary)' },
    }

    /** "HH:MM" ↔ 分钟数，和 Host 端 parseClock 同一套写法。 */
    function parseClock(text) {
      const m = /^(\d{1,2}):(\d{2})$/.exec(String(text || '').trim())
      if (m === null) return null
      const hour = Number(m[1])
      const minute = Number(m[2])
      if (hour > 23 || minute > 59) return null
      return { hour, minute }
    }

    function splitQuiet(label) {
      const m = /^(\d{2}:\d{2})–(\d{2}:\d{2})$/.exec(String(label || '').trim())
      if (m === null) return { start: '', end: '' }
      return { start: m[1], end: m[2] }
    }

    function Panel() {
      const [loading, setLoading] = useState(true)
      const [loadError, setLoadError] = useState('')
      const [settings, setSettings] = useState(null)
      const [status, setStatus] = useState(null)
      const [onKinds, setOnKinds] = useState([])
      const [quietStart, setQuietStart] = useState('')
      const [quietEnd, setQuietEnd] = useState('')
      const [busy, setBusy] = useState(false)
      const [message, setMessage] = useState(null)

      const absorb = useCallback((payload) => {
        const nextSettings = payload && payload.settings ? payload.settings : null
        const nextStatus = payload && payload.status ? payload.status : null
        if (nextSettings !== null) {
          setSettings(nextSettings)
          setOnKinds(Array.isArray(nextSettings.events) ? nextSettings.events : [])
          const quiet = splitQuiet(nextSettings.quietHours)
          setQuietStart(quiet.start)
          setQuietEnd(quiet.end)
        }
        if (nextStatus !== null) setStatus(nextStatus)
      }, [])

      const reload = useCallback(async () => {
        setLoading(true)
        setLoadError('')
        try {
          const response = await fetch(ENDPOINT, { headers: { accept: 'application/json' } })
          const payload = await response.json()
          if (payload.ok !== true) throw new Error(payload.error || '读取失败')
          absorb(payload)
        } catch (error) {
          setLoadError(error && error.message ? error.message : String(error))
        } finally {
          setLoading(false)
        }
      }, [absorb])

      useEffect(() => { void reload() }, [reload])

      const toggleKind = useCallback((kind, on) => {
        setOnKinds((current) => {
          const set = new Set(current)
          if (on) set.add(kind)
          else set.delete(kind)
          return Array.from(set)
        })
        setMessage(null)
      }, [])

      const save = useCallback(async () => {
        setBusy(true)
        setMessage(null)
        try {
          const body = {
            events: {},
            quietHours: {},
          }
          for (const row of KIND_ROWS) body.events[row.kind] = onKinds.indexOf(row.kind) !== -1
          const startOk = quietStart.trim() !== '' && quietEnd.trim() !== ''
          if (startOk) {
            if (parseClock(quietStart) === null || parseClock(quietEnd) === null) {
              throw new Error('免打扰时段要写成 HH:MM，比如 23:00')
            }
            if (quietStart.trim() === quietEnd.trim()) {
              throw new Error('免打扰的起止不能一样；不想设就两个都清空')
            }
            body.quietHours = { start: quietStart.trim(), end: quietEnd.trim() }
          }
          const response = await fetch(ENDPOINT, {
            method: 'POST',
            headers: { 'content-type': 'application/json', accept: 'application/json' },
            body: JSON.stringify(body),
          })
          const payload = await response.json()
          if (payload.ok !== true) throw new Error(payload.error || '保存失败')
          absorb(payload)
          if (payload.persisted === true) {
            setMessage({ level: 'ok', text: '已保存，并写进了配置文件。' })
          } else if (Array.isArray(payload.changed) && payload.changed.length === 0) {
            setMessage({ level: 'ok', text: '什么都没改。' })
          } else {
            setMessage({
              level: 'warn',
              text: `已经生效，但没写进配置文件：${payload.persistError || '原因不明'}。重启后会回到原来的值。`,
            })
          }
        } catch (error) {
          setMessage({ level: 'error', text: error && error.message ? error.message : String(error) })
        } finally {
          setBusy(false)
        }
      }, [absorb, onKinds, quietEnd, quietStart])

      const clearQuiet = useCallback(() => {
        setQuietStart('')
        setQuietEnd('')
        setMessage(null)
      }, [])

      if (loading) {
        return h('div', { style: styles.page }, h('div', { style: styles.sectionHint }, '正在读取提醒设置…'))
      }

      if (loadError !== '') {
        return h(
          'div',
          { style: styles.page },
          h('div', { style: styles.error }, `读不到提醒设置：${loadError}`),
          h('div', { style: styles.inline }, h('button', { type: 'button', style: styles.button, onClick: () => void reload() }, '重试')),
        )
      }

      const statLines = []
      if (status !== null) {
        const used = typeof status.todayNotified === 'number' ? status.todayNotified : 0
        const cap = settings !== null && typeof settings.maxNotifiesPerDay === 'number' ? settings.maxNotifiesPerDay : 0
        statLines.push(`今天已叫醒 ${used}/${cap} 次${cap === 0 ? '（0 = 只注入不叫醒）' : ''}`)
        if (typeof status.lastCheckAt === 'string' && status.lastCheckAt !== '') {
          statLines.push(`上次检查：${status.lastCheckAt}`)
        }
        if (status.inQuietHours === true) statLines.push('现在处在免打扰时段里，只注入不叫醒。')
        if (typeof status.lastError === 'string' && status.lastError !== '') {
          statLines.push(`上次错误：${status.lastError}`)
        }
      }

      return h(
        'div',
        { style: styles.page },

        h(
          'div',
          { style: styles.section },
          h('div', { style: styles.sectionTitle }, '提醒哪些事'),
          h('div', { style: styles.sectionHint },
            '关掉的那类事件不会再打扰你，但世界照常记录——回头用 world_now 还能看到。打工那类建议开着：几分钟内不处理就扣工钱。'),
          ...KIND_ROWS.map((row) => h(
            'label',
            { key: row.kind, style: styles.row },
            h('input', {
              type: 'checkbox',
              style: styles.checkbox,
              checked: onKinds.indexOf(row.kind) !== -1,
              onChange: (event) => toggleKind(row.kind, event.target.checked),
            }),
            h(
              'div',
              { style: styles.rowText },
              h('span', { style: styles.rowTitle }, row.title),
              row.hint === '' ? null : h('span', { style: styles.rowHint }, row.hint),
            ),
          )),
        ),

        h(
          'div',
          { style: styles.section },
          h('div', { style: styles.sectionTitle }, '免打扰时段'),
          h('div', { style: styles.sectionHint },
            '这段时间里只把事件放进会话，不叫醒你——事件不会丢，醒来还能看见。两个都留空就是全天都能叫醒。跨午夜也行（比如 23:00 到 07:00）。'),
          h(
            'div',
            { style: styles.inline },
            h('input', {
              type: 'time', style: styles.time, value: quietStart,
              onChange: (event) => { setQuietStart(event.target.value); setMessage(null) },
            }),
            h('span', { style: styles.sectionHint }, '到'),
            h('input', {
              type: 'time', style: styles.time, value: quietEnd,
              onChange: (event) => { setQuietEnd(event.target.value); setMessage(null) },
            }),
            h('button', { type: 'button', style: styles.button, onClick: clearQuiet }, '清空'),
          ),
        ),

        statLines.length === 0 ? null : h(
          'div',
          { style: styles.section },
          h('div', { style: styles.sectionTitle }, '现在的状态'),
          ...statLines.map((line, index) => h('div', { key: `stat-${index}`, style: styles.statLine }, line)),
        ),

        h(
          'div',
          { style: styles.inline },
          h('button', {
            type: 'button',
            style: styles.buttonPrimary,
            disabled: busy,
            onClick: () => void save(),
          }, busy ? '保存中…' : '保存'),
          h('button', { type: 'button', style: styles.button, disabled: busy, onClick: () => void reload() }, '重新读取'),
          message === null ? null : h(
            'span',
            { style: message.level === 'ok' ? styles.ok : (message.level === 'warn' ? styles.warn : styles.error) },
            message.text,
          ),
        ),
      )
    }

    return {
      inject: ['slots', 'locale'],
      apply(ctx) {
        const label = () => {
          try {
            const t = ctx.locale && typeof ctx.locale.bind === 'function' ? ctx.locale.bind('fishworld-reminder') : null
            return t !== null ? t('tab') : '鱼的世界提醒'
          } catch {
            return '鱼的世界提醒'
          }
        }
        ctx.slots.inject('settings.plugins.tab', () => ctx.slots.register({
          name: 'settings.plugins.tab',
          id: 'fishworld-reminder',
          order: 50,
          label,
        }, Panel))
      },
    }
  },
})
