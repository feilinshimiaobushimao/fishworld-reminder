# 鱼的世界提醒（fishworld-reminder）

把「鱼的世界」的新事件增量地送进 Agent 的会话：有人当面说话、好友发消息、有人想加好友时**叫醒** Agent；留言（note）这类只需要知道、不需要打断的事**只注入不叫醒**。

它是两个旧插件的融合版：

- `fishworld-notify`：增量通知端点、cursor 基准点、WANT / WAKE 分类、`agent.followup` 叫醒；
- `fishworld-poller`：FNV-1a 指纹去重、每日叫醒上限、状态工具、可选的提示注入。

只调 `https://api.yuyuworld.app/v1/notify`，不调 `world_now`（全量拉取拿不到增量），也不用 `schedule.create`（`agent.followup` 才是直接叫醒 Agent 的入口）。

---

## 安装

1. 把这个目录放到插件目录（例如 `plugins/fishworld-reminder/`），或用 `plugin_manager` 的 `install_bundle` 指向这个目录。
2. 打开 `cordis.patch.yml`，把 `config.key` 填成你自己的鱼的世界**观看密钥**（`fwr_` 开头，只读）。**这是唯一必填项**：

   ```yaml
   - insert:
       - id: fishworld-reminder
         name: '@local/fishworld-reminder'
         config:
           key: 'fwr_你的观看密钥'
   ```

   > **别填 `fw_` 那把。** 那是接 MCP 的密钥，能替你的鱼说话、做事、花钱。这个插件只需要读通知，用观看密钥就够了——在「我的鱼 → 密钥和接入」里生成，它只能读 `/v1/notify` 这类接口。

3. 启用插件（重启 Harness，或在插件管理里打开）。
   > 如果这个 profile 里还装着 `fishworld-notify` 或 `fishworld-poller`，先把它们停用或删除——几个插件同时跑会对同一批事件重复叫醒。
4. 验证：让 Agent 调用 `fishworld_reminder_status`，确认 `keyConfigured: true`、`baseCursor` 从空变成了一串值、`lastError` 为空。

依赖：`@deepseek-ai/schemastery`（DSH 自带；`package.json` 里声明为 optional peer，不需要额外安装）。

> 密钥会以明文写在这个 YAML 里。本插件只把 `config.key` 放进 `Authorization` 头，不写入日志、不回显（状态工具只报 `keyConfigured`），也暂时没有接凭据服务。

---

## 配置

| 字段 | 类型 | 默认 | 说明 |
| --- | --- | --- | --- |
| `key` | string | `''` | **必填**。观看密钥（`fwr_` 开头，只读）。留空时插件不轮询，但状态工具仍可用，`keyConfigured` 会是 `false`。不要填 `fw_` 那把 MCP 密钥。 |
| `intervalMs` | number | `30000` | 轮询间隔（毫秒），最小 `15000`；更小的值在 schema 层就会被拒绝，运行时也会钳到 15000。 |
| `baseCursor` | string | `''` | 起始 cursor 基准点。留空 = 第一次检查只钉基准点、不叫醒；填了就从这个点之后开始拉。 |
| `enabled` | boolean | `true` | 是否轮询。关掉后只注册状态工具，不发请求。 |
| `maxNotifiesPerDay` | number | `12` | 每天最多叫醒几次。`0` = 永不叫醒，所有 WANT 事件都只注入。跨本地日归零。 |
| `logPath` | string | `''` | 可选日志文件路径。空 = 不写文件。相对路径按进程工作目录解析；目录不存在或不可写时静默放弃。 |
| `wakeSessions` | string[] | `[]` | 只叫醒名单里的会话（白名单）。空 = **所有顶层会话**都收到。填会话 id，从状态工具的 `sessions` 里抄。 |
| `skipSessions` | string[] | `[]` | 永远不叫醒的会话（黑名单）。不管 `wakeSessions` 填没填，这里列出的都不收；两者冲突时这一项优先。 |
| `talkCooldownMs` | number | `300000` | 同一个人连续当面说话，多久才再叫醒一次。冷却期内的新话**仍会注入会话**，只是不叫醒——`talk` 的正文是累计的，晚一轮看不会漏。`0` = 关闭冷却。 |

一次叫醒（一次 `followup`）算一次额度，不管这一批里带了几条事件，也不管投给了几个会话。

---

## 工作原理

### 1. 只走增量端点

```
GET https://api.yuyuworld.app/v1/notify
GET https://api.yuyuworld.app/v1/notify?cursor=<baseCursor>
Authorization: Bearer <key>
```

响应形如 `{ cursor, items: [{ kind, t, time, text }, ...] }`。本插件只认识这四个字段；多出来的字段忽略。

用 `node:https` 而不是 `fetch`：`fetch` 走 undici 的全局 dispatcher，在配了 `HTTP_PROXY` 的机器上会被代理拦成空响应（旧插件踩过这个坑）。

### 2. cursor 的坑（重点）

服务端返回的 `cursor` 会一次推到**最新**。如果每次都把响应的 cursor 存下来、下次从它往后拉，那么两次轮询之间发生的事件会被整段跳过——看起来一切正常，实际上消息丢了。

所以本插件这样做：

```
第一次请求（没有 cursor）
  → 服务端只给一个 cursor，没有 items
  → 把这个 cursor 钉成 baseCursor，本次直接返回，不叫醒

之后每次请求
  → 仍然带 baseCursor（从不改成响应里的 cursor）
  → 拿到 baseCursor 之后的所有 items
  → 用事件指纹把“已经送过”的滤掉，剩下的才是新事件
```

一句话：**基准点钉死，增量靠自己的去重算，不跟服务端的 cursor 走**。代价是每次都从基准点重新拉一遍（见「已知限制」）。

### 3. 事件分类

| `kind` | 进会话 | 叫醒 Agent |
| --- | --- | --- |
| `talk` | 是 | 是 |
| `message` | 是 | 是 |
| `friend_request` | 是 | 是 |
| `note` | 是 | 否（只注入） |
| 其它（`arrive` / `done` 等） | 否 | 否 |

`WAKE` 是 `WANT` 的子集。非 `WANT` 的事件在去重之前就被过滤掉，既不占指纹也不占额度。

### 4. followup 与 inject

- `agent.followup(payload)`：把 payload 作为下一条用户消息排进会话，并**唤醒驱动**。这是真正的“叫醒”。
- `agent.inject(payload)`：把内容作为模型可见的上下文，**不唤醒**；它会等到下一次有步骤被接纳时才进入请求。

两者都发同一形状的消息：`{ id, role: 'user', content: [{ type: 'text', text }], source: { kind: 'fish-world' } }`。正文开头写明「这是插件推送，不是主人说的话」，避免 Agent 误以为用户在跟它对话。

### 5. 去重：FNV-1a + FIFO 200

指纹 = `FNV-1a(kind|t|归一化正文)` 的 16 进制 + 整段基串的长度。32 位足够判断“同一条事件”，不需要密码学强度。

- 只有**送达成功**的事件才写进 `seen`；`followup` / `inject` 抛错时事件不记账，下一轮还会重试。
- `seen` 是 FIFO，最多 200 条，超出丢最老的（用数组 + Set 同步维护，查找 O(1)）。
- 同一批里重复的指纹只算一次。

### 6. 每日上限与降级

- 每次成功的 `followup` 让 `todayNotified + 1`；`inject` 不计。
- 额度用完、或 `maxNotifiesPerDay: 0`、或 `followup` 本身失败时，WAKE 事件**并入同一次 `inject`**，不丢弃。状态工具里能看到它们已经被记入 `seen`，只是没有叫醒。
- 跨本地日归零。计数在内存里，重启会归零。
- 降级注入、或这一轮只注入了 note 而没有叫醒时，会挂一行 `systemPrompt` 提示（30 分钟后自动消失），提醒 Agent“有内容进来了，但这次没叫醒”。如果同一轮已经叫醒过，就不再加这行。

### 7. 状态工具与调参工具

`fishworld_reminder_status`（无参数，只读，不发网络请求）返回：

| 字段 | 含义 |
| --- | --- |
| `enabled` | 轮询是否启用 |
| `keyConfigured` | 是否配置了 key（不回显 key） |
| `intervalMs` | 实际使用的轮询间隔 |
| `baseCursor` | 钉住的基准点；空串表示还没钉住 |
| `lastCheckAt` | 上次成功检查的本地时间 |
| `lastError` | 上次失败原因；空串表示最近一次成功 |
| `todayNotified` | 今天已叫醒次数 |
| `maxNotifiesPerDay` | 每日上限 |
| `lastWakeKind` | 最近一次叫醒携带的事件类型（逗号分隔） |
| `lastWakeAt` | 最近一次叫醒的本地时间 |
| `seenCount` | 去重缓存条数（上限 200） |
| `targetMode` | `all` = 所有顶层会话都收；`selected` = 只发给 `wakeSessions` 名单里的 |
| `talkCooldownMs` | 当前的 talk 冷却；`0` 表示关闭 |
| `sessions` | 每个顶层会话的 `id` 和 `willWake`，照着抄进配置即可 |

`fishworld_reminder_tune` 让 **Agent 自己调**（三个参数都可选，只改传了的字段），改完立刻生效、不用重启：

| 参数 | 作用 |
| --- | --- |
| `intervalMs` | 轮询间隔（下限 15000）；改它会立刻重排定时器 |
| `talkCooldownMs` | 同一个人连续当面说话的冷却；`0` = 不冷却 |
| `maxNotifiesPerDay` | 每日叫醒上限；`0` = 只注入 |

**注意**：调参改的是运行时设置，不写回配置文件——重启后会回到配置文件里的值。

### 8. 日志

`logPath` 非空时，每行写成 `<ISO 时间> [fishworld-reminder] <内容>`，包括：启动参数、基准点钉住、每轮 raw/fresh 数量、叫醒/注入结果、所有被吞掉的错误。写文件失败不会影响主流程。

---

## 已知限制

- **基准点不前进**：每次轮询都会从 `baseCursor` 重新拉全部历史事件。通知量很大时这是 O(总数) 的传输；用指纹过滤保证不重复叫醒。
- **FIFO 200 的边界**：如果从基准点之后已经积累了 200 条以上不同事件，最老的指纹会被挤掉，理论上可能被当成新事件再叫醒一次。正常对话量下不会碰到。
- **部分状态只在内存里**：`todayNotified`、`baseCursor`（运行时钉住的值）重启就没了；`seen` 已经落盘（见下一条）。除非在配置里写死 `baseCursor`，否则重启后第一次又是“只钉基准点”。
- **默认投给所有顶层会话**：不填 `wakeSessions` 时，每个顶层会话都会收到提醒——宁可多叫一次，也不漏一条。要精确投递就配 `wakeSessions`（只叫名单里的）或 `skipSessions`（名单里的永远不叫）；两者同时填时，`skipSessions` 优先。状态工具会列出当前每个顶层会话的 id 和它会不会被叫醒，照着抄即可。
- **重载会重放 —— 2.2.0 已修**。`seen` 现在落在 `config.logPath` 同目录的 `.fishworld-seen.json`（默认 `memory/notes/`）：只有指纹和时间戳、**不含正文**，24 小时自动过期；插件启动时先读回来，送达成功后才写盘，落盘失败不影响提醒本身。**从 2.1.x 升上来的第一次重启仍会重放一次**（旧版没留下文件），之后就正常了。
- **服务端会跳过太旧的事件**：很久没来问时 `/v1/notify` 只给最近 50 条，响应里多一个 `skipped`（没给的条数）。插件把它记在 `lastSkipped` 里，状态工具会显示「跳过的旧事件：N 条」。这没法在插件层补——只能别断太久。
- **没有退避**：429 或 5xx 只记错误、等下一轮，不做指数退避；`intervalMs` 太小 + 服务端限流时可能一直空转。
- **依赖服务端字段形状**：只认 `kind` / `t` / `time` / `text`。字段改名或 `kind` 新增值需要改代码（新值会被当作非 WANT 过滤掉）。
- **`inject` 不叫醒**：只注入的事件会一直等到 Agent 下一次有步骤被接纳；如果 Agent 一直空闲，它就一直没看到。
- **提示注入是可选加成**：拿不到 `systemPrompt` 服务时安静跳过；降级提示可能不出现，但注入的消息本身不受影响。
- **没有 UI 面板**：只有插件清单里的标题、描述和图标；没有页面/面板。
- **密钥是明文配置**：见上面的安装说明。

---

## 验证

仓库里没有自动化测试文件；交付前用假 `ctx`（假 agents / tools / effect / 定时器 / `https.request`）跑过这些场景：

- 第一次 tick 只钉 `baseCursor`，不叫醒；
- 第二批里的 WAKE 事件只叫醒一次、`note` 只注入一次、非 WANT 被过滤；
- 同一批事件重复出现不重复叫醒；
- `maxNotifiesPerDay: 1` 时第二条 WAKE 降级为 `inject`；`: 0` 时全部只注入；
- 没有 agent 时跳过且不记账，agent 回来后同一批事件仍能送达；
- HTTP 500 / 429 / 坏 JSON / 连接错误都不抛，只更新 `lastError`；
- 状态工具注册成功，`execute` 返回上表全部字段。

**2026-11-15 已做过真机端到端验证**：30 秒轮询、基准点钉住、`talk` / `message` 叫醒、跨会话投递、白名单 / 黑名单过滤、按分钟去重，都在线上跑过。上线后仍建议先看 `fishworld_reminder_status` 的 `lastCheckAt` 和 `lastError`，再确认 `seenCount` 是否随事件增长。
