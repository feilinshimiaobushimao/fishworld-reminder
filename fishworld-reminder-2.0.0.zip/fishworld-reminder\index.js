/**
 * 鱼的世界 · 提醒（fishworld-reminder）
 *
 * 由两个旧插件融合而来：
 *   - fishworld-notify：增量通知端点 + cursor 基准点 + WANT/WAKE 分类 + `agent.followup`
 *     才是真正叫醒 Agent 的入口；
 *   - fishworld-poller：FNV-1a 指纹去重（FIFO 上限 200）、每日叫醒上限、状态工具、
 *     可选的 systemPrompt 一行提示。
 *
 * 只有一条取数路径：GET https://api.yuyuworld.app/v1/notify?cursor=...
 * 不调 world_now（全量拉取拿不到增量），也不用 schedule.create（绕远路）。
 *
 * 三条硬约束（改代码前先读）：
 *   1. 服务端返回的 cursor 会一次推到“最新”，跟着它走会跳过中间事件。所以第一次只
 *      钉住基准点，之后一直从基准点往后拉，靠指纹去重。见 pollOnce() 与 collectFresh()。
 *   2. 所有注册都包在 ctx.effect 里并返回清理函数；网络、解析、注册、投递异常全部
 *      吞掉只记日志，绝不抛。
 *   3. 每日叫醒额度用完后**降级为 inject**（只注入不叫醒），不丢弃事件。
 */
import https from 'node:https'
import { randomUUID } from 'node:crypto'
import { appendFile } from 'node:fs/promises'
import Schema from '@deepseek-ai/schemastery'

const PLUGIN_NAME = 'fishworld-reminder'
const API = 'https://api.yuyuworld.app/v1/notify'
const STATUS_TOOL = 'fishworld_reminder_status'

/** 值得进会话的事件；arrive / done 是日常流水，跳过（免得刷屏）。 */
const WANT = new Set(['talk', 'message', 'note', 'friend_request'])
/** 这几类会把会话叫醒：有人当面说话、好友发消息、有人想加好友。 */
const WAKE = new Set(['talk', 'message', 'friend_request'])

const DEFAULT_INTERVAL_MS = 30000
const MIN_INTERVAL_MS = 15000
const DEFAULT_MAX_NOTIFIES_PER_DAY = 12
/** 已提醒过的事件指纹最多记多少条（FIFO，超出丢最老的）。 */
const MAX_SEEN = 200
const HTTP_TIMEOUT_MS = 20000
const MAX_RESPONSE_BYTES = 1024 * 1024
const MAX_REDIRECTS = 3

/** 提示行排在其它运行时上下文之后（仓库里最大的 context order 是 210）。 */
const CONTEXT_ORDER = 5000
/** 降级注入后那行提示最多挂多久；过期就不再占用每轮上下文。 */
const HINT_TTL_MS = 30 * 60_000

export const inject = ['agents', 'tools']

export const Config = Schema.object({
  key: Schema.string()
    .default('')
    .description('鱼的世界通知密钥（v1/notify 用）。必填；留空时插件不轮询，但状态工具仍可用。Fish World notify key (required; polling stays off while empty).'),
  intervalMs: Schema.number()
    .default(DEFAULT_INTERVAL_MS)
    .min(MIN_INTERVAL_MS)
    .description('轮询间隔（毫秒），默认 30000，最小 15000。Poll interval in milliseconds (default 30000, minimum 15000).'),
  baseCursor: Schema.string()
    .default('')
    .description('起始 cursor 基准点。留空 = 第一次检查只钉基准点、不叫醒。Initial cursor baseline; empty pins one on the first check without waking.'),
  enabled: Schema.boolean()
    .default(true)
    .description('是否启用轮询。关掉后只保留状态工具。Whether polling is enabled; when off only the status tool remains.'),
  maxNotifiesPerDay: Schema.number()
    .default(DEFAULT_MAX_NOTIFIES_PER_DAY)
    .min(0)
    .description('每天最多叫醒几次；0 = 永不叫醒（只注入）。按本地日归零。Maximum wake-ups per local day; 0 = never wake (inject only).'),
  logPath: Schema.string()
    .default('')
    .description('可选日志文件路径；空 = 不写文件。相对路径按进程工作目录解析。Optional log file; empty disables file logging.'),
})

export function apply(ctx, config) {
  const settings = normalizeConfig(config)
  const log = createLogger(ctx, settings.logPath)
  const state = createState(settings)

  log.info(`apply: key=${settings.key === '' ? 'missing' : 'configured'} enabled=${settings.enabled} interval=${settings.intervalMs}ms`)

  // 状态工具先注册：即使没填 key 或轮询被关掉，Agent 也能查到“为什么没动”。
  installEffect(ctx, () => registerStatusTool(ctx, settings, state, log), log)

  // 可选的一行提示。systemPrompt 不在声明式 inject 里：拿不到就安静跳过，
  // 不让一个“锦上添花”的依赖挡住整个插件。
  installEffect(ctx, () => registerHint(ctx, state, log), log)

  if (!settings.enabled) {
    log.info('disabled by config; polling not started')
    return
  }
  if (settings.key === '') {
    log.warn('config.key is empty; polling not started (status tool is still available)')
    return
  }

  installEffect(ctx, () => startPolling(ctx, settings, state, log), log)
}

/* ------------------------------------------------------------------ 轮询 */

/** 定时器 + 首轮立刻跑一次；返回清理函数。 */
function startPolling(ctx, settings, state, log) {
  let stopped = false
  let inFlight = false

  const tick = async () => {
    if (stopped || inFlight) return
    inFlight = true
    try {
      await pollOnce(ctx, settings, state, log)
    } catch (error) {
      // pollOnce 自己已经兜了大部分；这里是最后一道保险。
      state.lastError = `轮询异常：${describeError(error)}`
      log.warn(state.lastError)
    } finally {
      inFlight = false
    }
  }

  const stopTimer = startInterval(ctx, () => { void tick() }, settings.intervalMs)
  void tick()

  return () => {
    stopped = true
    safeCall(stopTimer)
  }
}

/**
 * 查一次。任何失败只更新 state.lastError 并记日志，绝不抛。
 *
 * cursor 的坑：服务端会把 cursor 推到最新。第一次请求只返回基准点（没有 items），
 * 我们把它钉在 state.baseCursor 里；之后**从不**用响应里的 cursor 覆盖它，每次仍从
 * 基准点往后拉，用指纹把看过的事件滤掉。这样中间事件不会因为 cursor 跳跃而丢失。
 */
async function pollOnce(ctx, settings, state, log) {
  const url = state.baseCursor === ''
    ? API
    : `${API}?cursor=${encodeURIComponent(state.baseCursor)}`

  let response
  try {
    response = await getJson(url, settings.key)
  } catch (error) {
    state.lastError = `请求失败：${describeError(error)}`
    log.warn(state.lastError)
    return
  }

  if (response.status === 429) {
    state.lastError = 'HTTP 429（被限流，下一轮再试）'
    log.warn(state.lastError)
    return
  }
  if (response.status < 200 || response.status >= 300) {
    state.lastError = `HTTP ${response.status}${response.parseError === undefined ? '' : `（${response.parseError}）`}`
    log.warn(state.lastError)
    return
  }
  if (response.data === undefined) {
    state.lastError = response.parseError === undefined ? '返回不是合法 JSON' : response.parseError
    log.warn(state.lastError)
    return
  }

  state.lastCheckAt = Date.now()
  state.lastError = ''

  // 第一次：只钉基准点。服务端这时不返回内容。
  if (state.baseCursor === '') {
    const cursor = isObject(response.data) && typeof response.data.cursor === 'string'
      ? response.data.cursor
      : ''
    if (cursor === '') {
      state.lastError = '首次检查没有返回 cursor'
      log.warn(state.lastError)
      return
    }
    state.baseCursor = cursor
    log.info(`base cursor pinned: ${cursor}`)
    return
  }

  const raw = isObject(response.data) && Array.isArray(response.data.items)
    ? response.data.items
    : []

  // 先确认能拿到 agent，再去重/记账——否则一次没有会话的轮询会把事件白白吞掉。
  const agent = firstRoot(ctx)
  if (agent === undefined) {
    log.info(`no live agent; ${raw.length} item(s) left unread`)
    return
  }

  const fresh = collectFresh(raw, state)
  if (fresh.wake.length === 0 && fresh.quiet.length === 0) {
    log.info(`check ok raw=${raw.length} fresh=0`)
    return
  }

  await deliver(settings, state, log, agent, fresh)
}

/** 取第一个顶层会话；拿不到就返回 undefined（不猜、不投）。 */
function firstRoot(ctx) {
  try {
    const agents = ctx.agents
    if (!isObject(agents) || typeof agents.roots !== 'function') return undefined
    const roots = agents.roots()
    if (!Array.isArray(roots) || roots.length === 0) return undefined
    const agent = roots[0]
    return isObject(agent) ? agent : undefined
  } catch {
    return undefined
  }
}

/* ------------------------------------------------------------------ 投递 */

/**
 * 把一批新事件分两路送出：
 *   - WAKE 类 → 一次 `followup`（真正叫醒），成功才计入每日额度；
 *   - 其余 WANT 类 → 一次 `inject`（只注入，不叫醒）。
 * 额度用完 / 额度为 0 / followup 失败时，WAKE 事件**降级**并入 inject，而不是丢掉。
 * 只有送达成功的指纹才会记入 seen；失败的下轮还会再试。
 */
async function deliver(settings, state, log, agent, fresh) {
  const now = Date.now()
  const cap = settings.maxNotifiesPerDay
  const used = notifiesToday(state, now)

  const injectItems = [...fresh.quiet]
  let degraded = ''
  let woke = false

  if (fresh.wake.length > 0) {
    if (cap === 0) {
      degraded = 'maxNotifiesPerDay=0，只注入不叫醒'
    } else if (used >= cap) {
      degraded = `今天已叫醒 ${used}/${cap} 次，额度用完，只注入不叫醒`
    } else {
      try {
        await callAgent(agent, 'followup', buildPayload(fresh.wake, 'wake'))
        woke = true
        // 一次叫醒算一次额度（同一批里几条事件都算这一次）。
        rememberAll(state, fresh.wake)
        state.dayKey = dayKeyOf(now)
        state.dayCount = used + 1
        state.lastWakeKind = uniqueKinds(fresh.wake)
        state.lastWakeAt = now
        state.hint = null
        log.info(`woke agent with ${fresh.wake.length} event(s): ${state.lastWakeKind}`)
      } catch (error) {
        degraded = `叫醒失败（${describeError(error)}），改为只注入`
        log.warn(degraded)
      }
    }
    if (!woke) injectItems.push(...fresh.wake)
  }

  if (injectItems.length === 0) return

  try {
    await callAgent(agent, 'inject', buildPayload(injectItems, degraded === '' ? 'quiet' : 'degraded', degraded))
    rememberAll(state, injectItems)
    if (degraded === '') {
      log.info(`injected ${injectItems.length} quiet event(s) without waking`)
    } else {
      log.info(`injected ${injectItems.length} event(s) without waking: ${degraded}`)
    }
    // 这一轮没有叫醒（只有 note，或额度/失败降级）时，留一行提示；
    // 如果同轮已经叫醒过，就不必再重复提醒。
    if (!woke) state.hint = { at: now, text: buildHint(now, degraded, injectItems.length) }
  } catch (error) {
    state.lastError = `注入失败：${describeError(error)}`
    log.warn(state.lastError)
  }
}

/** 调 agent 的 followup / inject；同时容忍同步抛错和返回 Promise 两种形态。 */
async function callAgent(agent, method, payload) {
  const fn = agent[method]
  if (typeof fn !== 'function') throw new Error(`agent.${method} 不可用`)
  const result = fn.call(agent, payload)
  if (isObject(result) && typeof result.then === 'function') await result
}

/**
 * 构造 Agent 能接受的 user 消息。形状沿用 fishworld-notify 线上验证过的那一份：
 * { id, role: 'user', content: [{ type: 'text', text }], source: { kind } }。
 * 文案必须说明“这是插件推送、不是主人说话”，避免 Agent 误认为是用户在对话。
 */
function buildPayload(entries, mode, note) {
  const header = mode === 'wake'
    ? '【鱼的世界·有人找你】'
    : mode === 'degraded'
      ? '【鱼的世界·只注入不叫醒】'
      : '【鱼的世界·旁听记录】'

  const lines = entries
    .map((entry) => `${entry.time === '' ? '' : `${entry.time} `}${entry.text}`.trim())
    .join('\n')

  const footer = mode === 'wake'
    ? '（这是插件推送的提醒，不是主人说的话；原话用 world_now 看）'
    : `（这是插件推送、不叫醒你的记录，不是主人说的话${note === '' ? '' : `；${note}`}；原话用 world_now 看）`

  return {
    id: randomUUID(),
    role: 'user',
    content: [{ type: 'text', text: `${header}\n${lines === '' ? '（没有正文）' : lines}\n${footer}` }],
    source: { kind: 'fish-world' },
  }
}

/** 降级 / 只注入后挂到 systemPrompt 的那一行；30 分钟后自动失效。 */
function buildHint(now, reason, count) {
  const head = reason === ''
    ? `【鱼的世界】${formatTime(now)} 有 ${count} 条新事件只注入了会话，没有叫醒你。`
    : `【鱼的世界】${formatTime(now)} 有人找你，但这次没有叫醒你（${reason}）。`
  return `${head}内容已经注入会话；想看提醒状态可以调用 ${STATUS_TOOL}。`
}

/* -------------------------------------------------------------- 状态工具 */

function registerStatusTool(ctx, settings, state, log) {
  const tools = ctx.tools
  if (!isObject(tools) || typeof tools.register !== 'function') {
    log.warn('tools service is unavailable; status tool not registered')
    return () => {}
  }

  const definition = {
    name: STATUS_TOOL,
    description:
      '查看「鱼的世界」提醒的当前状态：是否启用、密钥是否已配置、轮询间隔、基准 cursor、'
      + '上次检查时间与错误、今天已叫醒几次、最近一次叫醒、去重缓存条数。'
      + '只读，不发网络请求；怀疑提醒没在工作时先看这里。',
    parameters: {
      type: 'object',
      properties: {},
      additionalProperties: false,
    },
    output: {
      schema: {
        type: 'object',
        properties: {
          enabled: { type: 'boolean', description: '轮询是否启用。' },
          keyConfigured: { type: 'boolean', description: '是否配置了 key（不会回显 key 本身）。' },
          intervalMs: { type: 'number', description: '实际使用的轮询间隔（毫秒）。' },
          baseCursor: { type: 'string', description: '钉住的 cursor 基准点；空串表示还没钉住。' },
          lastCheckAt: { type: 'string', description: '上次成功检查的本地时间；空串表示还没成功过。' },
          lastError: { type: 'string', description: '上次失败原因；空串表示最近一次检查成功。' },
          todayNotified: { type: 'number', description: '今天已经叫醒过几次（按本地日归零）。' },
          maxNotifiesPerDay: { type: 'number', description: '每天叫醒上限；0 表示只注入不叫醒。' },
          lastWakeKind: { type: 'string', description: '最近一次叫醒携带的事件类型，逗号分隔；空串表示还没叫醒过。' },
          lastWakeAt: { type: 'string', description: '最近一次叫醒的本地时间；空串表示还没叫醒过。' },
          seenCount: { type: 'number', description: '去重缓存里现有的事件指纹条数（上限 200）。' },
        },
        additionalProperties: false,
      },
      render(_args, value) {
        return renderStatus(value)
      },
    },
    async execute() {
      try {
        return snapshot(settings, state)
      } catch (error) {
        log.warn(`status snapshot failed: ${describeError(error)}`)
        return fallbackSnapshot(settings)
      }
    },
  }

  try {
    return tools.register(definition)
  } catch (error) {
    log.warn(`status tool registration failed: ${describeError(error)}`)
    return () => {}
  }
}

function snapshot(settings, state) {
  const now = Date.now()
  return {
    enabled: settings.enabled,
    keyConfigured: settings.key !== '',
    intervalMs: settings.intervalMs,
    baseCursor: state.baseCursor,
    lastCheckAt: state.lastCheckAt === 0 ? '' : formatTime(state.lastCheckAt),
    lastError: state.lastError,
    todayNotified: notifiesToday(state, now),
    maxNotifiesPerDay: settings.maxNotifiesPerDay,
    lastWakeKind: state.lastWakeKind,
    lastWakeAt: state.lastWakeAt === 0 ? '' : formatTime(state.lastWakeAt),
    seenCount: state.seen.length,
  }
}

function fallbackSnapshot(settings) {
  return {
    enabled: settings.enabled,
    keyConfigured: settings.key !== '',
    intervalMs: settings.intervalMs,
    baseCursor: '',
    lastCheckAt: '',
    lastError: '读取状态失败',
    todayNotified: 0,
    maxNotifiesPerDay: settings.maxNotifiesPerDay,
    lastWakeKind: '',
    lastWakeAt: '',
    seenCount: 0,
  }
}

function renderStatus(value) {
  try {
    const report = isObject(value) ? value : {}
    const cap = typeof report.maxNotifiesPerDay === 'number' ? report.maxNotifiesPerDay : 0
    const used = typeof report.todayNotified === 'number' ? report.todayNotified : 0
    const seen = typeof report.seenCount === 'number' ? report.seenCount : 0

    const lines = [
      `鱼的世界提醒：${report.enabled === true ? '已启用' : '已停用（不轮询）'}`,
      `密钥：${report.keyConfigured === true ? '已配置' : '未配置（提醒不会启动）'}`,
      `轮询间隔：${typeof report.intervalMs === 'number' ? report.intervalMs : 0} ms`,
      `基准 cursor：${typeof report.baseCursor === 'string' && report.baseCursor !== '' ? report.baseCursor : '还没钉住（下一次检查只拿基准点）'}`,
      `上次检查：${typeof report.lastCheckAt === 'string' && report.lastCheckAt !== '' ? report.lastCheckAt : '还没成功检查过'}`,
      `今天已叫醒：${used}/${cap} 次${cap === 0 ? '（0 = 只注入，不叫醒）' : ''}`,
      `最近叫醒：${typeof report.lastWakeKind === 'string' && report.lastWakeKind !== '' ? `${report.lastWakeKind} @ ${report.lastWakeAt}` : '还没有'}`,
      `去重缓存：${seen}/${MAX_SEEN} 条事件指纹`,
      `上次错误：${typeof report.lastError === 'string' && report.lastError !== '' ? report.lastError : '无'}`,
    ]
    return [{ type: 'text', text: lines.join('\n') }]
  } catch {
    return [{ type: 'text', text: '提醒状态读不出来；可以稍后再试。' }]
  }
}

/* ------------------------------------------------------- 可选：提示注入 */

/** 拿得到 systemPrompt 就注册一行运行时上下文；拿不到安静跳过（不是硬依赖）。 */
function registerHint(ctx, state, log) {
  let systemPrompt
  try {
    systemPrompt = typeof ctx.get === 'function' ? ctx.get('systemPrompt') : undefined
  } catch {
    systemPrompt = undefined
  }

  if (!isObject(systemPrompt) || typeof systemPrompt.context !== 'function') {
    log.info('systemPrompt unavailable; prompt hint disabled')
    return () => {}
  }

  return systemPrompt.context({
    name: PLUGIN_NAME,
    order: CONTEXT_ORDER,
    text: () => hintText(state),
  })
}

function hintText(state) {
  try {
    const hint = state.hint
    if (!isObject(hint) || typeof hint.text !== 'string' || typeof hint.at !== 'number') return ''
    if (Date.now() - hint.at > HINT_TTL_MS) return ''
    return hint.text
  } catch {
    return ''
  }
}

/* ------------------------------------------------------------ 去重与指纹 */

/**
 * 把 WANT 里还没见过的事件挑出来，按“叫醒 / 只注入”分组。
 * 非 WANT 直接过滤；同一批里重复的指纹也只算一次。
 */
function collectFresh(raw, state) {
  const wake = []
  const quiet = []
  const batch = new Set()

  for (const item of raw) {
    try {
      if (!isObject(item)) continue
      const kind = String(item.kind ?? '')
      if (!WANT.has(kind)) continue

      const fingerprint = fingerprintOf(item)
      if (state.seenSet.has(fingerprint) || batch.has(fingerprint)) continue
      batch.add(fingerprint)

      const entry = {
        kind,
        fingerprint,
        text: typeof item.text === 'string' ? item.text : '',
        time: itemTime(item),
      }
      if (WAKE.has(kind)) wake.push(entry)
      else quiet.push(entry)
    } catch {
      // 单条坏数据不影响整批
    }
  }

  return { wake, quiet }
}

/**
 * 事件指纹：kind + 时间戳 + 归一化正文的 FNV-1a，再带上正文长度降低碰撞。
 * 32 位够做“同一条事件”的判等，不需要密码学强度（旧 poller 的做法）。
 */
function fingerprintOf(item) {
  const kind = String(item.kind ?? '')
  const stamp = item.t ?? item.time ?? ''
  const text = typeof item.text === 'string' ? item.text : ''
  const basis = `${kind}|${stamp}|${collapseWhitespace(text)}`
  return `${fnv1a(basis)}-${basis.length}`
}

/** 32 位 FNV-1a。 */
function fnv1a(text) {
  let hash = 0x811c9dc5
  for (let index = 0; index < text.length; index += 1) {
    hash ^= text.charCodeAt(index)
    hash = Math.imul(hash, 0x01000193) >>> 0
  }
  return hash.toString(16).padStart(8, '0')
}

/** 送成功之后才记账；FIFO 上限 200。 */
function rememberAll(state, entries) {
  for (const entry of entries) remember(state, entry.fingerprint)
}

function remember(state, fingerprint) {
  if (typeof fingerprint !== 'string' || fingerprint === '') return
  if (state.seenSet.has(fingerprint)) return
  state.seen.push(fingerprint)
  state.seenSet.add(fingerprint)
  while (state.seen.length > MAX_SEEN) {
    const oldest = state.seen.shift()
    if (typeof oldest === 'string') state.seenSet.delete(oldest)
  }
}

/* ---------------------------------------------------------------- 小工具 */

function createState(settings) {
  return {
    /** 第一次拿到后就钉住，不再跟着响应里的 cursor 走。 */
    baseCursor: settings.baseCursor,
    /** 指纹数组（FIFO）与它的 Set 索引，两个一起维护。 */
    seen: [],
    seenSet: new Set(),
    /** 本地日计数。 */
    dayKey: '',
    dayCount: 0,
    lastCheckAt: 0,
    lastError: '',
    lastWakeKind: '',
    lastWakeAt: 0,
    /** 降级注入后给 systemPrompt 的一行提示：{ at, text } 或 null。 */
    hint: null,
  }
}

function normalizeConfig(config) {
  const source = isObject(config) ? config : {}

  const key = typeof source.key === 'string' ? source.key.trim() : ''
  const intervalMs = typeof source.intervalMs === 'number' && Number.isFinite(source.intervalMs)
    ? Math.max(MIN_INTERVAL_MS, Math.round(source.intervalMs))
    : DEFAULT_INTERVAL_MS
  const baseCursor = typeof source.baseCursor === 'string' ? source.baseCursor.trim() : ''
  const enabled = source.enabled !== false
  const maxNotifiesPerDay = typeof source.maxNotifiesPerDay === 'number' && Number.isFinite(source.maxNotifiesPerDay)
    ? Math.max(0, Math.round(source.maxNotifiesPerDay))
    : DEFAULT_MAX_NOTIFIES_PER_DAY
  const logPath = typeof source.logPath === 'string' ? source.logPath.trim() : ''

  return { key, intervalMs, baseCursor, enabled, maxNotifiesPerDay, logPath }
}

/** 当天叫醒次数；跨本地日自动归零（不落盘，重启也归零）。 */
function notifiesToday(state, now) {
  return state.dayKey === dayKeyOf(now) ? state.dayCount : 0
}

function dayKeyOf(timestamp) {
  const date = new Date(timestamp)
  const two = (value) => String(value).padStart(2, '0')
  return `${date.getFullYear()}-${two(date.getMonth() + 1)}-${two(date.getDate())}`
}

function uniqueKinds(entries) {
  const kinds = []
  for (const entry of entries) {
    if (!kinds.includes(entry.kind)) kinds.push(entry.kind)
  }
  return kinds.join(',')
}

function itemTime(item) {
  const value = item.time ?? item.t
  if (typeof value === 'string' && value !== '') return value
  if (typeof value === 'number' && Number.isFinite(value)) return formatTime(value)
  return formatTime(Date.now())
}

function formatTime(timestamp) {
  if (typeof timestamp !== 'number' || !Number.isFinite(timestamp)) return ''
  const date = new Date(timestamp)
  const two = (value) => String(value).padStart(2, '0')
  return `${date.getFullYear()}-${two(date.getMonth() + 1)}-${two(date.getDate())} `
    + `${two(date.getHours())}:${two(date.getMinutes())}:${two(date.getSeconds())}`
}

function collapseWhitespace(text) {
  if (typeof text !== 'string') return ''
  return text.replace(/\s+/g, ' ').trim()
}

function isObject(value) {
  return value !== null && typeof value === 'object'
}

function describeError(error) {
  try {
    if (isObject(error) && typeof error.message === 'string') return error.message
    return String(error)
  } catch {
    return 'unknown error'
  }
}

/* ------------------------------------------------------------------ 网络 */

/**
 * GET 一个 JSON。用 node:https 而不是 fetch：fetch 走 undici 的全局 dispatcher，
 * 在配了 HTTP_PROXY 的机器上会被代理拦成空响应（旧插件踩过）。
 *
 * 永远 resolve `{ status, data, parseError? }` 而不是因为非 2xx 抛错；只有真正的
 * 传输错误才 reject。调用方按 status 分支处理。
 */
function getJson(url, key, redirectsLeft = MAX_REDIRECTS) {
  return new Promise((resolve, reject) => {
    let settled = false
    const settle = (fn, value) => {
      if (settled) return
      settled = true
      fn(value)
    }

    let req
    try {
      req = https.request(
        url,
        {
          method: 'GET',
          headers: {
            authorization: `Bearer ${key}`,
            accept: 'application/json',
          },
        },
        (res) => {
          const status = typeof res.statusCode === 'number' ? res.statusCode : 0
          const location = isObject(res.headers) && typeof res.headers.location === 'string'
            ? res.headers.location
            : ''

          if (status >= 300 && status < 400 && location !== '' && redirectsLeft > 0) {
            try {
              safeCall(() => res.resume?.())
              const next = new URL(location, url).toString()
              getJson(next, key, redirectsLeft - 1).then(
                (value) => settle(resolve, value),
                (error) => settle(reject, error),
              )
            } catch (error) {
              settle(reject, error)
            }
            return
          }

          let body = ''
          let bytes = 0
          res.setEncoding('utf8')
          res.on('data', (chunk) => {
            bytes += Buffer.byteLength(chunk)
            if (bytes > MAX_RESPONSE_BYTES) {
              safeCall(() => req.destroy(new Error('response too large')))
              return
            }
            body += chunk
          })
          res.on('end', () => {
            if (body === '') {
              settle(resolve, { status, data: undefined, parseError: 'empty response' })
              return
            }
            try {
              settle(resolve, { status, data: JSON.parse(body) })
            } catch {
              settle(resolve, {
                status,
                data: undefined,
                parseError: `bad json (${status}): ${body.slice(0, 120)}`,
              })
            }
          })
          res.on('error', (error) => settle(reject, error))
        },
      )
    } catch (error) {
      settle(reject, error)
      return
    }

    req.setTimeout(HTTP_TIMEOUT_MS, () => {
      safeCall(() => req.destroy(new Error('timeout')))
    })
    req.on('error', (error) => settle(reject, error))
    req.end()
  })
}

/* -------------------------------------------------------------- 生命周期 */

/**
 * 把一次注册包进 ctx.effect，并保证：
 *   - install 抛错只记日志，不打断 apply；
 *   - 返回的清理函数一定会被 effect 收走。
 */
function installEffect(ctx, install, log) {
  if (!isObject(ctx) || typeof ctx.effect !== 'function') {
    // 没有 effect 的宿主：至少把功能装上，代价是卸载可能不及时。
    try {
      const dispose = install()
      // 这里不能调用 dispose：没有 effect 就没有卸载时机，立刻调用等于当场注销。
      void dispose
    } catch (error) {
      log.warn(`install failed: ${describeError(error)}`)
    }
    return
  }

  try {
    ctx.effect(() => {
      try {
        const dispose = install()
        return typeof dispose === 'function' ? dispose : () => {}
      } catch (error) {
        log.warn(`install failed: ${describeError(error)}`)
        return () => {}
      }
    })
  } catch (error) {
    log.warn(`effect registration failed: ${describeError(error)}`)
  }
}

/** 宿主有 ctx.setInterval 就用它（自带清理）；否则退回全局定时器并 unref。 */
function startInterval(ctx, callback, intervalMs) {
  try {
    if (typeof ctx.setInterval === 'function') return ctx.setInterval(callback, intervalMs)
  } catch {
    // 继续尝试下一种
  }

  const handle = setInterval(callback, intervalMs)
  if (isObject(handle) && typeof handle.unref === 'function') handle.unref()
  return () => clearInterval(handle)
}

/**
 * 日志：优先用宿主 logger（ctx.logger 可能是函数，也可能是对象），
 * 同时可选追加到 logPath。写不出去就安静放弃，绝不因为日志失败影响主流程。
 */
function createLogger(ctx, logPath) {
  let logger
  try {
    if (isObject(ctx) && typeof ctx.logger === 'function') logger = ctx.logger(PLUGIN_NAME)
    else if (isObject(ctx) && isObject(ctx.logger)) logger = ctx.logger
  } catch {
    logger = undefined
  }

  const emit = (level, message) => {
    const line = `[${PLUGIN_NAME}] ${message}`
    try {
      const method = isObject(logger) && typeof logger[level] === 'function' ? logger[level] : undefined
      if (method !== undefined) method.call(logger, line)
      else if (level === 'warn' && typeof console !== 'undefined' && typeof console.warn === 'function') console.warn(line)
    } catch {
      // 日志失败不影响主流程
    }

    if (logPath !== '') {
      try {
        void appendFile(logPath, `${new Date().toISOString()} ${line}\n`, 'utf8').catch(() => {})
      } catch {
        // 路径不可写就算了
      }
    }
  }

  return {
    info: (message) => emit('info', message),
    warn: (message) => emit('warn', message),
  }
}

function safeCall(fn) {
  try {
    if (typeof fn === 'function') fn()
  } catch {
    // 清理失败不影响卸载
  }
}
